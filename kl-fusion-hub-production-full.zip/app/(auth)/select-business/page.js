'use client';

import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/browser';
import { businessSchema } from '@/lib/schemas';
import { slugify } from '@/lib/format';
import { TextField, TextAreaField } from '@/components/Field';
import SectionCard from '@/components/SectionCard';

export default function SelectBusinessPage() {
  const supabase = createClient();
  const [user, setUser] = useState(null);
  const [memberships, setMemberships] = useState([]);
  const [values, setValues] = useState({ name: '', slug: '', description: '' });
  const [message, setMessage] = useState('');

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser();
      setUser(user || null);

      if (!user) return;

      const { data } = await supabase
        .from('memberships')
        .select('id, role, business:businesses(id, name, slug, description, created_at)')
        .eq('user_id', user.id)
        .eq('status', 'active')
        .order('created_at', { ascending: false });

      setMemberships(data || []);
    }

    load();
  }, [supabase]);

  async function createBusiness(event) {
    event.preventDefault();
    setMessage('');

    try {
      const payload = {
        name: values.name,
        slug: values.slug || slugify(values.name),
      };

      businessSchema.parse(payload);

      const { error } = await supabase.from('businesses').insert({
        name: payload.name,
        slug: payload.slug,
        description: values.description,
        owner_id: user.id,
      });

      if (error) throw error;
      setValues({ name: '', slug: '', description: '' });
      setMessage('Business created. Return to the dashboard to start using it.');
      const { data } = await supabase
        .from('memberships')
        .select('id, role, business:businesses(id, name, slug, description, created_at)')
        .eq('user_id', user.id)
        .eq('status', 'active')
        .order('created_at', { ascending: false });
      setMemberships(data || []);
    } catch (error) {
      setMessage(error.message || 'Could not create business');
    }
  }

  return (
    <main className="page-wrap">
      <SectionCard title="Your businesses" description="Pick an existing tenant or create a new one.">
        <div className="grid gap-3">
          {!memberships.length ? (
            <div className="rounded-2xl border border-dashed p-4 text-sm text-slate-500">No businesses yet.</div>
          ) : memberships.map((item) => (
            <div key={item.id} className="rounded-2xl border p-4">
              <div className="font-semibold">{item.business?.name}</div>
              <div className="mt-1 text-sm text-slate-500">{item.business?.slug}</div>
              <div className="mt-3">
                <a href="/dashboard" className="btn-primary">Open dashboard</a>
              </div>
            </div>
          ))}
        </div>
      </SectionCard>

      <SectionCard title="Create a business" description="This creates the business, owner membership, settings, default location and register.">
        <form className="grid gap-4 md:grid-cols-2" onSubmit={createBusiness}>
          <TextField
            label="Business name"
            value={values.name}
            onChange={(e) => {
              const name = e.target.value;
              setValues((current) => ({ ...current, name, slug: current.slug || slugify(name) }));
            }}
            placeholder="KL Fusion Retail"
          />
          <TextField
            label="Slug"
            value={values.slug}
            onChange={(e) => setValues((current) => ({ ...current, slug: slugify(e.target.value) }))}
            placeholder="kl-fusion-retail"
          />
          <div className="md:col-span-2">
            <TextAreaField
              label="Description"
              value={values.description}
              onChange={(e) => setValues((current) => ({ ...current, description: e.target.value }))}
              placeholder="Retail + service business"
            />
          </div>
          <div className="md:col-span-2 flex flex-wrap gap-3">
            <button className="btn-primary" type="submit">Create business</button>
            <a className="btn-soft" href="/dashboard">Back to dashboard</a>
          </div>
        </form>

        {message ? <div className="mt-4 rounded-2xl border p-3 text-sm">{message}</div> : null}
      </SectionCard>
    </main>
  );
}
