import AuthCard from '@/features/auth/AuthCard';

export default function RegisterPage() {
  return <AuthCard mode="register" />;
}
