import POSPage from '@/features/pos/POSPage';

export default function Page() {
  return <POSPage />;
}
