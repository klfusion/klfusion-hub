import CrudPage from '@/features/entities/CrudPage';

const fields=[{name:'description',label:'Description'},{name:'category',label:'Category'},{name:'amount',label:'Amount',type:'number'},{name:'expense_date',label:'Expense date',type:'date'},{name:'payment_method',label:'Payment method'},{name:'notes',label:'Notes',type:'textarea',span:2}];
const columns=[{key:'description',label:'Description'},{key:'category',label:'Category'},{key:'amount',label:'Amount',type:'money'},{key:'expense_date',label:'Expense date',type:'date'}];

export default function Page(){ return <CrudPage title='Expenses' description='Track operational spend, supplier costs and reportable expenses.' table='expenses' fields={fields} columns={columns} defaultValues={{description:'',category:'',amount:0,expense_date:new Date().toISOString().slice(0,10),payment_method:'',notes:''}} />; }
