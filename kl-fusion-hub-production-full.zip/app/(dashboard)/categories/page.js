import CrudPage from '@/features/entities/CrudPage';

const fields=[{name:'name',label:'Name'},{name:'description',label:'Description',type:'textarea',span:2},{name:'is_active',label:'Active',type:'checkbox'}];
const columns=[{key:'name',label:'Name'},{key:'description',label:'Description'},{key:'created_at',label:'Created',type:'date'}];

export default function Page(){ return <CrudPage title='Categories' description='Organize products for reporting and quick POS lookup.' table='categories' fields={fields} columns={columns} defaultValues={{name:'',description:'',is_active:true}} />; }
