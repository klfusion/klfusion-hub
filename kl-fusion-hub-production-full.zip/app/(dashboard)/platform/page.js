import PlatformPage from '@/features/platform/PlatformPage';

export default function Page() {
  return <PlatformPage />;
}
