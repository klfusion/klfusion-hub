import SalesHistoryPage from '@/features/sales/SalesHistoryPage';

export default function Page() {
  return <SalesHistoryPage />;
}
