import CrudPage from '@/features/entities/CrudPage';

const fields=[{name:'name',label:'Customer name'},{name:'code',label:'Code'},{name:'email',label:'Email',type:'email'},{name:'phone',label:'Phone'},{name:'address',label:'Address',type:'textarea',span:2},{name:'tax_number',label:'Tax number'},{name:'credit_limit',label:'Credit limit',type:'number'},{name:'notes',label:'Notes',type:'textarea',span:2},{name:'is_active',label:'Active',type:'checkbox'}];
const columns=[{key:'name',label:'Name'},{key:'email',label:'Email'},{key:'phone',label:'Phone'},{key:'credit_limit',label:'Credit limit',type:'money'}];

export default function Page(){ return <CrudPage title='Customers' description='Customers, balances and invoice recipients.' table='customers' fields={fields} columns={columns} defaultValues={{name:'',code:'',email:'',phone:'',address:'',tax_number:'',credit_limit:0,notes:'',is_active:true}} />; }
