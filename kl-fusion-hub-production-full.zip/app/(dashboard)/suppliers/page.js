import CrudPage from '@/features/entities/CrudPage';

const fields=[{name:'name',label:'Supplier name'},{name:'code',label:'Code'},{name:'email',label:'Email',type:'email'},{name:'phone',label:'Phone'},{name:'address',label:'Address',type:'textarea',span:2},{name:'contact_person',label:'Contact person'},{name:'notes',label:'Notes',type:'textarea',span:2},{name:'is_active',label:'Active',type:'checkbox'}];
const columns=[{key:'name',label:'Name'},{key:'contact_person',label:'Contact'},{key:'email',label:'Email'},{key:'phone',label:'Phone'}];

export default function Page(){ return <CrudPage title='Suppliers' description='Suppliers used for purchasing, receiving and vendor reporting.' table='suppliers' fields={fields} columns={columns} defaultValues={{name:'',code:'',email:'',phone:'',address:'',contact_person:'',notes:'',is_active:true}} />; }
