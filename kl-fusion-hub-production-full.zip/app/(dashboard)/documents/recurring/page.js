import RecurringPage from '@/features/documents/RecurringPage';

export default function Page() {
  return <RecurringPage />;
}
