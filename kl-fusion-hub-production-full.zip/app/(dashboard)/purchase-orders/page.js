import PurchaseOrdersPage from '@/features/purchasing/PurchaseOrdersPage';

export default function Page() {
  return <PurchaseOrdersPage />;
}
