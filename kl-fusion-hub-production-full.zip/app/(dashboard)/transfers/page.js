import TransfersPage from '@/features/transfers/TransfersPage';

export default function Page() {
  return <TransfersPage />;
}
