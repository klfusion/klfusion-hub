import { redirect } from 'next/navigation';
import AppShell from '@/components/AppShell';
import { createClient } from '@/lib/supabase/server';

export default async function DashboardLayout({ children }) {
  const supabase = await createClient();

  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    redirect('/login');
  }

  const [{ data: profile }, { data: memberships }] = await Promise.all([
    supabase.from('profiles').select('*').eq('id', user.id).maybeSingle(),
    supabase
      .from('memberships')
      .select('id, role, business:businesses(id, name, slug, is_active)')
      .eq('user_id', user.id)
      .eq('status', 'active'),
  ]);

  const initialBusinesses = (memberships || [])
    .filter((row) => row.business)
    .map((row) => ({
      ...row.business,
      membership_role: row.role,
    }));

  return (
    <AppShell
      initialUser={user}
      initialProfile={profile}
      initialBusinesses={initialBusinesses}
    >
      {children}
    </AppShell>
  );
}
