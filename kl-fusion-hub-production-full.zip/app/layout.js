import './globals.css';
import { APP_NAME } from '@/lib/constants';

export const metadata = {
  title: APP_NAME,
  description: 'Multi-business SaaS management app for KL Fusion',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>{children}</body>
    </html>
  );
}
