import Link from 'next/link';
import { createAdminClient } from '@/lib/supabase/admin';
import SectionCard from '@/components/SectionCard';
import PortalActions from '@/features/portal/PortalActions';
import { currency, shortDate } from '@/lib/format';

async function getPortalDocument(token) {
  const admin = createAdminClient();
  const { data, error } = await admin.rpc('get_portal_document', {
    portal_token: token,
  });

  if (error) {
    throw error;
  }

  return data;
}

export default async function PortalDocumentPage({ params }) {
  let payload = null;
  let message = '';

  try {
    payload = await getPortalDocument(params.token);
  } catch (error) {
    message = error.message || 'Portal document not available';
  }

  if (!payload) {
    return (
      <main className="page-wrap">
        <SectionCard title="Document portal" description="This link is invalid or expired.">
          <div className="rounded-2xl border border-dashed p-4 text-sm text-slate-500">{message || 'No document found.'}</div>
        </SectionCard>
      </main>
    );
  }

  const { business, settings, customer, document, items } = payload;

  return (
    <main className="page-wrap">
      <SectionCard title={document.document_type === 'invoice' ? 'Invoice portal' : 'Quote portal'} description={`Shared by ${business?.name || 'your supplier'}`}>
        <div className="grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">
          <div className="panel p-5">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <div className="text-xs uppercase tracking-[0.25em] text-sky-500">{business?.name}</div>
                <div className="mt-2 text-3xl font-bold">{document.number}</div>
                <div className="mt-2 text-sm text-slate-500">
                  {document.document_type.toUpperCase()} · {shortDate(document.issue_date)} · Due {shortDate(document.due_date)}
                </div>
              </div>
              <span className="badge-muted capitalize">{document.status}</span>
            </div>

            <div className="mt-6 grid gap-3">
              {(items || []).map((item) => (
                <div key={item.id} className="rounded-2xl border p-3">
                  <div className="font-medium">{item.name_snapshot}</div>
                  <div className="mt-1 text-sm text-slate-500">{item.quantity} × {currency(item.unit_price, settings?.currency_symbol || 'R')}</div>
                  <div className="mt-2 text-sm font-semibold">{currency(item.line_total, settings?.currency_symbol || 'R')}</div>
                </div>
              ))}
            </div>

            <div className="mt-6 rounded-2xl bg-slate-50 p-4 text-sm dark:bg-slate-900">
              <div className="flex justify-between"><span>Subtotal</span><span>{currency(document.subtotal, settings?.currency_symbol || 'R')}</span></div>
              <div className="mt-2 flex justify-between"><span>Tax</span><span>{currency(document.tax_total, settings?.currency_symbol || 'R')}</span></div>
              <div className="mt-2 flex justify-between text-lg font-semibold"><span>Total</span><span>{currency(document.total, settings?.currency_symbol || 'R')}</span></div>
            </div>
          </div>

          <div className="grid gap-5">
            <SectionCard title="Customer" description="Recipient details">
              <div className="space-y-2 text-sm">
                <div><span className="font-semibold">Name:</span> {customer?.name || 'Customer'}</div>
                <div><span className="font-semibold">Email:</span> {customer?.email || '—'}</div>
                <div><span className="font-semibold">Phone:</span> {customer?.phone || '—'}</div>
              </div>
            </SectionCard>

            <SectionCard title="Next actions" description={document.document_type === 'quote' ? 'Quotes can be accepted or declined from this portal.' : 'Invoices can be viewed and downloaded as PDF.'}>
              <PortalActions token={params.token} documentId={document.id} documentType={document.document_type} />
              <div className="mt-3">
                <Link href="/" className="btn-soft">Back to site</Link>
              </div>
            </SectionCard>
          </div>
        </div>
      </SectionCard>
    </main>
  );
}
