import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { buildDocumentPdf } from '@/lib/pdf/buildDocumentPdf';

export async function GET(request, { params }) {
  try {
    const supabase = await createClient();

    const [{ data: document }, { data: items }] = await Promise.all([
      supabase.from('documents').select('*, customer:customers(*), business:businesses(*)').eq('id', params.id).maybeSingle(),
      supabase.from('document_items').select('*').eq('document_id', params.id).order('created_at'),
    ]);

    if (!document) {
      return NextResponse.json({ ok: false, error: 'Document not found' }, { status: 404 });
    }

    const { data: settings } = await supabase
      .from('business_settings')
      .select('*')
      .eq('business_id', document.business_id)
      .maybeSingle();

    const bytes = await buildDocumentPdf({
      business: document.business,
      settings,
      customer: document.customer,
      document,
      items,
    });

    return new NextResponse(bytes, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `inline; filename="${document.number || document.id}.pdf"`,
      },
    });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error.message || 'Could not generate PDF' }, { status: 400 });
  }
}
