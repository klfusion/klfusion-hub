import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export async function POST(request, { params }) {
  try {
    const supabase = await createClient();
    const { data, error } = await supabase.rpc('create_portal_token', {
      target_document_id: params.id,
    });

    if (error) throw error;

    const base = process.env.NEXT_PUBLIC_APP_URL || new URL(request.url).origin;
    return NextResponse.json({ ok: true, url: `${base}/portal/${data}` });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error.message || 'Could not create share link' }, { status: 400 });
  }
}
