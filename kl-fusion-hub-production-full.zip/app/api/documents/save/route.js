import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export async function POST(request) {
  try {
    const body = await request.json();
    const supabase = await createClient();
    const { data, error } = await supabase.rpc('save_document', {
      payload: body,
    });

    if (error) throw error;
    return NextResponse.json({ ok: true, document_id: data });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error.message || 'Could not save document' }, { status: 400 });
  }
}
