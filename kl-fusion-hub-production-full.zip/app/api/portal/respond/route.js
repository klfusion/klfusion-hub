import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';

export async function POST(request) {
  try {
    const body = await request.json();
    const supabase = createAdminClient();
    const { data, error } = await supabase.rpc('respond_to_quote', {
      portal_token: body.token,
      decision: body.decision,
    });

    if (error) throw error;
    return NextResponse.json({ ok: true, document_id: data });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error.message || 'Could not update quote status' }, { status: 400 });
  }
}
