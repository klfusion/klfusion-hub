import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { buildReceiptPdf } from '@/lib/pdf/buildReceiptPdf';

export async function GET(request, { params }) {
  try {
    const supabase = await createClient();

    const [{ data: sale }, { data: items }] = await Promise.all([
      supabase.from('sales').select('*, business:businesses(*)').eq('id', params.saleId).maybeSingle(),
      supabase.from('sale_items').select('*').eq('sale_id', params.saleId).order('created_at'),
    ]);

    if (!sale) {
      return NextResponse.json({ ok: false, error: 'Sale not found' }, { status: 404 });
    }

    const { data: settings } = await supabase
      .from('business_settings')
      .select('*')
      .eq('business_id', sale.business_id)
      .maybeSingle();

    const bytes = await buildReceiptPdf({
      business: sale.business,
      settings,
      sale,
      items,
    });

    return new NextResponse(bytes, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `inline; filename="${sale.sale_number || sale.id}-receipt.pdf"`,
      },
    });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error.message || 'Could not generate receipt' }, { status: 400 });
  }
}
