import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export async function POST(request, { params }) {
  try {
    const body = await request.json();
    const supabase = await createClient();
    const { data, error } = await supabase.rpc('process_refund', {
      payload: {
        sale_id: params.saleId,
        refund_method: body.refund_method,
        reason: body.reason,
        items: body.items || [],
      },
    });

    if (error) throw error;
    return NextResponse.json({ ok: true, refund_id: data });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error.message || 'Refund failed' }, { status: 400 });
  }
}
