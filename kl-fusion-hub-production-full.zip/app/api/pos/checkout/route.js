import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export async function POST(request) {
  try {
    const payload = await request.json();
    const supabase = await createClient();

    const { data, error } = await supabase.rpc('process_sale', {
      payload,
    });

    if (error) {
      throw error;
    }

    return NextResponse.json({ ok: true, sale_id: data });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error.message || 'Checkout failed' }, { status: 400 });
  }
}
