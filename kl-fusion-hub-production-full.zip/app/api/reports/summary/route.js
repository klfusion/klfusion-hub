import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const businessId = searchParams.get('businessId');
    const locationId = searchParams.get('locationId');
    const supabase = await createClient();

    const { data, error } = await supabase.rpc('report_summary', {
      target_business_id: businessId,
      target_location_id: locationId || null,
    });

    if (error) throw error;

    return NextResponse.json({ ok: true, data });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error.message || 'Could not load report summary' }, { status: 400 });
  }
}
