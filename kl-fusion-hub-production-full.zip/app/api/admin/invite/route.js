import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export async function POST(request) {
  try {
    const body = await request.json();
    const token = crypto.randomUUID();

    const supabase = await createClient();
    const { error } = await supabase.from('invitations').insert({
      business_id: body.business_id,
      email: body.email,
      role: body.role,
      token,
      status: 'pending',
      expires_at: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toISOString(),
    });

    if (error) throw error;

    const base = process.env.NEXT_PUBLIC_APP_URL || new URL(request.url).origin;
    return NextResponse.json({ ok: true, url: `${base}/invite/${token}` });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error.message || 'Could not create invitation' }, { status: 400 });
  }
}
