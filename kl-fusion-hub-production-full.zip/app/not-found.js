import Link from 'next/link';

export default function NotFound() {
  return (
    <main className="page-wrap">
      <section className="panel p-8 text-center">
        <h1 className="text-3xl font-bold">Page not found</h1>
        <p className="mt-3 text-slate-500">The page you tried to open does not exist.</p>
        <div className="mt-6">
          <Link href="/dashboard" className="btn-primary">Back to dashboard</Link>
        </div>
      </section>
    </main>
  );
}
