'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import SectionCard from '@/components/SectionCard';

export default function InvitationPage({ params }) {
  const router = useRouter();
  const [message, setMessage] = useState('');

  async function accept() {
    const response = await fetch('/api/invitations/accept', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: params.token }),
    });
    const data = await response.json();
    if (!response.ok) {
      setMessage(data.error || 'Could not accept invitation');
      return;
    }
    router.push('/dashboard');
  }

  return (
    <main className="page-wrap">
      <SectionCard title="Business invitation" description="Accept this invitation after signing into your account.">
        <div className="flex flex-wrap gap-3">
          <button className="btn-primary" onClick={accept}>Accept invitation</button>
          <a className="btn-soft" href="/login">Sign in</a>
        </div>
        {message ? <div className="mt-4 rounded-2xl border p-3 text-sm">{message}</div> : null}
      </SectionCard>
    </main>
  );
}
