'use client';

import { useEffect, useMemo, useState } from 'react';
import { createClient } from '@/lib/supabase/browser';
import { useApp } from '@/components/BusinessProvider';
import { CURRENCIES, EMPTY_DRAFT } from '@/lib/constants';
import SectionCard from '@/components/SectionCard';
import DataGrid from '@/components/DataGrid';
import ModalSheet from '@/components/ModalSheet';
import { SelectField, TextAreaField, TextField, CheckboxField } from '@/components/Field';
import { currency, shortDate } from '@/lib/format';

export default function DocumentsPage({ documentType = 'invoice' }) {
  const supabase = createClient();
  const { currentBusiness, currentLocation, settings } = useApp();
  const [documents, setDocuments] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState({
    ...EMPTY_DRAFT,
    recurring: { enabled: false, frequency: 'monthly', interval_value: 1, next_run_at: new Date().toISOString().slice(0, 10) },
  });
  const [message, setMessage] = useState('');

  useEffect(() => {
    load();
  }, [currentBusiness?.id]);

  async function load() {
    if (!currentBusiness?.id) return;

    const [{ data: docRows }, { data: customerRows }, { data: productRows }] = await Promise.all([
      supabase
        .from('documents')
        .select('*, customer:customers(name)')
        .eq('business_id', currentBusiness.id)
        .eq('document_type', documentType)
        .order('created_at', { ascending: false }),
      supabase.from('customers').select('id, name').eq('business_id', currentBusiness.id).eq('is_active', true).order('name'),
      supabase.from('products').select('id, name, price, tax_rate').eq('business_id', currentBusiness.id).eq('is_active', true).order('name'),
    ]);

    setDocuments(docRows || []);
    setCustomers(customerRows || []);
    setProducts(productRows || []);
  }

  function createNew() {
    setDraft({
      ...EMPTY_DRAFT,
      currency_code: settings?.currency_code || 'ZAR',
      recurring: { enabled: false, frequency: 'monthly', interval_value: 1, next_run_at: new Date().toISOString().slice(0, 10) },
    });
    setMessage('');
    setOpen(true);
  }

  function updateItem(index, updates) {
    setDraft((current) => ({
      ...current,
      items: current.items.map((item, i) => i === index ? { ...item, ...updates } : item),
    }));
  }

  function addItem() {
    setDraft((current) => ({
      ...current,
      items: [...current.items, { product_id: '', name_snapshot: '', description: '', quantity: 1, unit_price: 0, tax_rate: 15 }],
    }));
  }

  function removeItem(index) {
    setDraft((current) => ({
      ...current,
      items: current.items.filter((_, i) => i !== index),
    }));
  }

  const subtotal = draft.items.reduce((sum, item) => sum + (Number(item.quantity || 0) * Number(item.unit_price || 0)), 0);
  const tax = draft.items.reduce((sum, item) => sum + (Number(item.quantity || 0) * Number(item.unit_price || 0) * Number(item.tax_rate || 0) / 100), 0);
  const total = subtotal + tax;

  async function save(event) {
    event.preventDefault();
    const response = await fetch('/api/documents/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        business_id: currentBusiness.id,
        location_id: currentLocation?.id || null,
        document_type: documentType,
        customer_id: draft.customer_id || null,
        issue_date: draft.issue_date,
        due_date: draft.due_date,
        po_number: draft.po_number,
        notes: draft.notes,
        terms: draft.terms,
        currency_code: draft.currency_code || settings?.currency_code || 'ZAR',
        items: draft.items,
        recurring: documentType === 'invoice' ? draft.recurring : undefined,
      }),
    });
    const data = await response.json();
    if (!response.ok) {
      setMessage(data.error || 'Could not save document');
      return;
    }
    setOpen(false);
    await load();
  }

  async function share(row) {
    const response = await fetch(`/api/documents/${row.id}/share`, { method: 'POST' });
    const data = await response.json();
    if (!response.ok) {
      setMessage(data.error || 'Could not create share link');
      return;
    }
    navigator.clipboard.writeText(data.url);
    setMessage('Share link copied to clipboard.');
  }

  const customerOptions = useMemo(() => customers.map((item) => ({ value: item.id, label: item.name })), [customers]);
  const productOptions = useMemo(() => products.map((item) => ({ value: item.id, label: item.name })), [products]);

  return (
    <div className="page-wrap">
      <SectionCard
        title={documentType === 'invoice' ? 'Invoices' : 'Quotations'}
        description={documentType === 'invoice'
          ? 'Invoices support numbering, PDF output, portal links, reminders and recurring templates.'
          : 'Quotes can be branded, shared publicly and accepted or declined through the customer portal.'}
        actions={<button className="btn-primary" onClick={createNew}>New {documentType}</button>}
      >
        {message ? <div className="mb-4 rounded-2xl border p-3 text-sm">{message}</div> : null}
        <DataGrid
          columns={[
            { key: 'number', label: 'Number' },
            { key: 'customer', label: 'Customer', render: (row) => row.customer?.name || 'Walk-in' },
            { key: 'issue_date', label: 'Issue date', render: (row) => shortDate(row.issue_date) },
            { key: 'due_date', label: 'Due date', render: (row) => shortDate(row.due_date) },
            { key: 'status', label: 'Status', render: (row) => <span className="badge-muted capitalize">{row.status}</span> },
            { key: 'total', label: 'Total', render: (row) => currency(row.total, settings?.currency_symbol || 'R') },
            {
              key: 'actions',
              label: 'Actions',
              render: (row) => (
                <div className="flex flex-wrap gap-2">
                  <a className="btn-soft" href={`/api/documents/${row.id}/pdf`} target="_blank" rel="noreferrer">PDF</a>
                  <button className="btn-soft" onClick={() => share(row)}>Share</button>
                </div>
              ),
            },
          ]}
          rows={documents}
        />
      </SectionCard>

      <ModalSheet
        open={open}
        title={`New ${documentType}`}
        onClose={() => setOpen(false)}
        footer={
          <div className="flex flex-wrap gap-3">
            <button className="btn-primary" onClick={save}>Save {documentType}</button>
            <button className="btn-soft" onClick={() => setOpen(false)}>Cancel</button>
          </div>
        }
      >
        <form className="grid gap-4" onSubmit={save}>
          <div className="grid gap-4 sm:grid-cols-2">
            <SelectField label="Customer" value={draft.customer_id} onChange={(e) => setDraft((c) => ({ ...c, customer_id: e.target.value }))} options={customerOptions} />
            <SelectField label="Currency" value={draft.currency_code || 'ZAR'} onChange={(e) => setDraft((c) => ({ ...c, currency_code: e.target.value }))} options={CURRENCIES} />
            <TextField label="Issue date" type="date" value={draft.issue_date} onChange={(e) => setDraft((c) => ({ ...c, issue_date: e.target.value }))} />
            <TextField label={documentType === 'invoice' ? 'Due date' : 'Valid until'} type="date" value={draft.due_date} onChange={(e) => setDraft((c) => ({ ...c, due_date: e.target.value }))} />
            <TextField label="PO number" value={draft.po_number} onChange={(e) => setDraft((c) => ({ ...c, po_number: e.target.value }))} />
          </div>

          <div className="grid gap-3">
            {draft.items.map((item, index) => (
              <div key={index} className="rounded-3xl border p-4">
                <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
                  <SelectField
                    label="Product"
                    value={item.product_id || ''}
                    options={productOptions}
                    onChange={(e) => {
                      const product = products.find((row) => row.id === e.target.value);
                      updateItem(index, {
                        product_id: e.target.value,
                        name_snapshot: product?.name || '',
                        unit_price: Number(product?.price || 0),
                        tax_rate: Number(product?.tax_rate || 0),
                      });
                    }}
                  />
                  <TextField label="Description" value={item.name_snapshot} onChange={(e) => updateItem(index, { name_snapshot: e.target.value })} />
                  <TextField label="Quantity" type="number" value={item.quantity} onChange={(e) => updateItem(index, { quantity: e.target.value })} />
                  <TextField label="Unit price" type="number" value={item.unit_price} onChange={(e) => updateItem(index, { unit_price: e.target.value })} />
                  <TextField label="Tax %" type="number" value={item.tax_rate} onChange={(e) => updateItem(index, { tax_rate: e.target.value })} />
                </div>
                <div className="mt-3">
                  <button className="btn-danger" type="button" onClick={() => removeItem(index)}>Remove line</button>
                </div>
              </div>
            ))}
          </div>

          <div>
            <button className="btn-soft" type="button" onClick={addItem}>Add line item</button>
          </div>

          {documentType === 'invoice' ? (
            <div className="rounded-3xl border p-4">
              <div className="mb-3 text-sm font-semibold">Recurring billing</div>
              <div className="grid gap-4 sm:grid-cols-3">
                <CheckboxField
                  label="Enable recurring invoice"
                  checked={Boolean(draft.recurring?.enabled)}
                  onChange={(e) => setDraft((c) => ({ ...c, recurring: { ...c.recurring, enabled: e.target.checked } }))}
                />
                <SelectField
                  label="Frequency"
                  value={draft.recurring?.frequency || 'monthly'}
                  onChange={(e) => setDraft((c) => ({ ...c, recurring: { ...c.recurring, frequency: e.target.value } }))}
                  options={[
                    { value: 'daily', label: 'Daily' },
                    { value: 'weekly', label: 'Weekly' },
                    { value: 'monthly', label: 'Monthly' },
                    { value: 'quarterly', label: 'Quarterly' },
                    { value: 'yearly', label: 'Yearly' },
                  ]}
                />
                <TextField
                  label="Interval"
                  type="number"
                  value={draft.recurring?.interval_value || 1}
                  onChange={(e) => setDraft((c) => ({ ...c, recurring: { ...c.recurring, interval_value: e.target.value } }))}
                />
              </div>
            </div>
          ) : null}

          <TextAreaField label="Notes" value={draft.notes} onChange={(e) => setDraft((c) => ({ ...c, notes: e.target.value }))} />
          <TextAreaField label="Terms" value={draft.terms} onChange={(e) => setDraft((c) => ({ ...c, terms: e.target.value }))} />

          <div className="rounded-3xl bg-slate-50 p-4 text-sm dark:bg-slate-900">
            <div className="flex justify-between"><span>Subtotal</span><span>{currency(subtotal, settings?.currency_symbol || 'R')}</span></div>
            <div className="mt-2 flex justify-between"><span>Tax</span><span>{currency(tax, settings?.currency_symbol || 'R')}</span></div>
            <div className="mt-2 flex justify-between text-lg font-semibold"><span>Total</span><span>{currency(total, settings?.currency_symbol || 'R')}</span></div>
          </div>
        </form>
        {message ? <div className="mt-4 rounded-2xl border p-3 text-sm">{message}</div> : null}
      </ModalSheet>
    </div>
  );
}
