'use client';

import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/browser';
import { useApp } from '@/components/BusinessProvider';
import SectionCard from '@/components/SectionCard';
import DataGrid from '@/components/DataGrid';
import { shortDate } from '@/lib/format';

export default function RecurringPage() {
  const supabase = createClient();
  const { currentBusiness } = useApp();
  const [rows, setRows] = useState([]);

  useEffect(() => {
    async function load() {
      if (!currentBusiness?.id) return;
      const { data } = await supabase
        .from('recurring_document_templates')
        .select('*, source_document:documents(number, document_type)')
        .eq('business_id', currentBusiness.id)
        .order('created_at', { ascending: false });
      setRows(data || []);
    }
    load();
  }, [currentBusiness?.id]);

  return (
    <div className="page-wrap">
      <SectionCard
        title="Recurring invoices"
        description="Templates generated from invoices. Use Supabase cron or a server scheduler to trigger the SQL job that materializes due recurrences."
      >
        <DataGrid
          columns={[
            { key: 'source_document', label: 'Source', render: (row) => row.source_document?.number || '—' },
            { key: 'frequency', label: 'Frequency' },
            { key: 'interval_value', label: 'Interval' },
            { key: 'next_run_at', label: 'Next run', render: (row) => shortDate(row.next_run_at) },
            { key: 'is_active', label: 'Active', render: (row) => row.is_active ? <span className="badge-success">Active</span> : <span className="badge-muted">Paused</span> },
          ]}
          rows={rows}
        />
      </SectionCard>
    </div>
  );
}
