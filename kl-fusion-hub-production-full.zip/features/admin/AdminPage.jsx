'use client';

import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/browser';
import { useApp } from '@/components/BusinessProvider';
import { ROLES } from '@/lib/constants';
import SectionCard from '@/components/SectionCard';
import DataGrid from '@/components/DataGrid';
import { SelectField, TextField } from '@/components/Field';
import { datetime } from '@/lib/format';

export default function AdminPage() {
  const supabase = createClient();
  const { currentBusiness, role } = useApp();
  const [members, setMembers] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [invite, setInvite] = useState({ email: '', role: 'cashier' });
  const [message, setMessage] = useState('');

  useEffect(() => {
    load();
  }, [currentBusiness?.id]);

  async function load() {
    if (!currentBusiness?.id) return;

    const [{ data: memberRows }, { data: logRows }] = await Promise.all([
      supabase
        .from('memberships')
        .select('id, role, status, created_at, user:profiles(full_name, email)')
        .eq('business_id', currentBusiness.id)
        .order('created_at', { ascending: false }),
      supabase
        .from('audit_logs')
        .select('*')
        .eq('business_id', currentBusiness.id)
        .order('created_at', { ascending: false })
        .limit(25),
    ]);

    setMembers(memberRows || []);
    setAuditLogs(logRows || []);
  }

  async function updateRole(memberId, nextRole) {
    const { error } = await supabase.from('memberships').update({ role: nextRole }).eq('id', memberId);
    if (error) {
      setMessage(error.message || 'Could not update role');
      return;
    }
    await load();
  }

  async function toggleStatus(member) {
    const { error } = await supabase.from('memberships').update({ status: member.status === 'active' ? 'inactive' : 'active' }).eq('id', member.id);
    if (error) {
      setMessage(error.message || 'Could not update member status');
      return;
    }
    await load();
  }

  async function sendInvite(event) {
    event.preventDefault();
    setMessage('');
    const response = await fetch('/api/admin/invite', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ business_id: currentBusiness.id, ...invite }),
    });
    const data = await response.json();
    if (!response.ok) {
      setMessage(data.error || 'Could not create invitation');
      return;
    }
    setMessage(`Invitation created. Share this link: ${data.url}`);
    setInvite({ email: '', role: 'cashier' });
  }

  if (!['owner', 'admin'].includes(role || '')) {
    return (
      <div className="page-wrap">
        <SectionCard title="Admin" description="Only owners and admins can manage access.">
          <div className="rounded-2xl border border-dashed p-4 text-sm text-slate-500">You do not have permission to manage this business.</div>
        </SectionCard>
      </div>
    );
  }

  return (
    <div className="page-wrap">
      <SectionCard title="Team access" description="Role management, deactivation and invitation links.">
        <form className="mb-4 grid gap-4 sm:grid-cols-[2fr_1fr_auto]" onSubmit={sendInvite}>
          <TextField label="Invite email" type="email" value={invite.email} onChange={(e) => setInvite((c) => ({ ...c, email: e.target.value }))} />
          <SelectField label="Role" value={invite.role} onChange={(e) => setInvite((c) => ({ ...c, role: e.target.value }))} options={ROLES} />
          <div className="pt-7">
            <button className="btn-primary w-full" type="submit">Create invite</button>
          </div>
        </form>

        {message ? <div className="mb-4 rounded-2xl border p-3 text-sm">{message}</div> : null}

        <DataGrid
          columns={[
            { key: 'user', label: 'User', render: (row) => row.user?.full_name || row.user?.email || '—' },
            { key: 'email', label: 'Email', render: (row) => row.user?.email || '—' },
            { key: 'role', label: 'Role', render: (row) => (
              <select className="field py-2" value={row.role} onChange={(e) => updateRole(row.id, e.target.value)}>
                {ROLES.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}
              </select>
            )},
            { key: 'status', label: 'Status', render: (row) => <span className="badge-muted capitalize">{row.status}</span> },
            { key: 'actions', label: 'Actions', render: (row) => <button className="btn-soft" onClick={() => toggleStatus(row)}>{row.status === 'active' ? 'Deactivate' : 'Activate'}</button> },
          ]}
          rows={members}
        />
      </SectionCard>

      <SectionCard title="Audit log" description="Operational trail for admin changes and key business events.">
        <DataGrid
          columns={[
            { key: 'created_at', label: 'Date', render: (row) => datetime(row.created_at) },
            { key: 'action', label: 'Action' },
            { key: 'entity_table', label: 'Entity' },
            { key: 'entity_id', label: 'Record' },
          ]}
          rows={auditLogs}
        />
      </SectionCard>
    </div>
  );
}
