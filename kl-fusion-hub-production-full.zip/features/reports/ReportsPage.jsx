'use client';

import { useEffect, useState } from 'react';
import { useApp } from '@/components/BusinessProvider';
import SectionCard from '@/components/SectionCard';
import DataGrid from '@/components/DataGrid';
import { currency } from '@/lib/format';

export default function ReportsPage() {
  const { currentBusiness, currentLocation, settings } = useApp();
  const [summary, setSummary] = useState(null);

  useEffect(() => {
    async function load() {
      if (!currentBusiness?.id) return;
      const url = new URL('/api/reports/summary', window.location.origin);
      url.searchParams.set('businessId', currentBusiness.id);
      if (currentLocation?.id) url.searchParams.set('locationId', currentLocation.id);
      const response = await fetch(url.toString());
      const data = await response.json();
      setSummary(data.data || null);
    }
    load();
  }, [currentBusiness?.id, currentLocation?.id]);

  return (
    <div className="page-wrap">
      <SectionCard title="Reporting" description="Operational revenue, product rankings, low stock visibility and cash drivers.">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <div className="rounded-3xl border p-4">
            <div className="text-xs uppercase tracking-wide text-slate-400">Today sales</div>
            <div className="mt-2 text-2xl font-bold">{currency(summary?.today_sales || 0, settings?.currency_symbol || 'R')}</div>
          </div>
          <div className="rounded-3xl border p-4">
            <div className="text-xs uppercase tracking-wide text-slate-400">Month sales</div>
            <div className="mt-2 text-2xl font-bold">{currency(summary?.month_sales || 0, settings?.currency_symbol || 'R')}</div>
          </div>
          <div className="rounded-3xl border p-4">
            <div className="text-xs uppercase tracking-wide text-slate-400">Month expenses</div>
            <div className="mt-2 text-2xl font-bold">{currency(summary?.month_expenses || 0, settings?.currency_symbol || 'R')}</div>
          </div>
          <div className="rounded-3xl border p-4">
            <div className="text-xs uppercase tracking-wide text-slate-400">Open invoice balance</div>
            <div className="mt-2 text-2xl font-bold">{currency(summary?.open_invoice_balance || 0, settings?.currency_symbol || 'R')}</div>
          </div>
        </div>
      </SectionCard>

      <div className="grid gap-5 xl:grid-cols-2">
        <SectionCard title="Top products" description="Best performing items by quantity sold.">
          <DataGrid
            columns={[
              { key: 'product_name', label: 'Product' },
              { key: 'units_sold', label: 'Units sold' },
              { key: 'sales_total', label: 'Sales total', render: (row) => currency(row.sales_total, settings?.currency_symbol || 'R') },
            ]}
            rows={summary?.top_products || []}
          />
        </SectionCard>

        <SectionCard title="Low stock products" description="Replenishment candidates by location.">
          <DataGrid
            columns={[
              { key: 'product_name', label: 'Product' },
              { key: 'location_name', label: 'Location' },
              { key: 'quantity_on_hand', label: 'On hand' },
              { key: 'low_stock_point', label: 'Reorder point' },
            ]}
            rows={summary?.low_stock || []}
          />
        </SectionCard>
      </div>
    </div>
  );
}
