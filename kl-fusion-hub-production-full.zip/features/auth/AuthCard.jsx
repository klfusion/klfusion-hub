'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useMemo, useState } from 'react';
import { createClient } from '@/lib/supabase/browser';
import { authSchema } from '@/lib/schemas';
import { TextField } from '@/components/Field';

export default function AuthCard({ mode = 'login' }) {
  const supabase = createClient();
  const router = useRouter();
  const [values, setValues] = useState({ email: '', password: '', full_name: '' });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const isLogin = mode === 'login';
  const title = useMemo(() => (isLogin ? 'Welcome back' : 'Create your account'), [isLogin]);

  async function submit(event) {
    event.preventDefault();
    setMessage('');

    try {
      authSchema.parse({
        email: values.email,
        password: values.password,
      });
      setLoading(true);

      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({
          email: values.email,
          password: values.password,
        });
        if (error) throw error;
        router.push('/dashboard');
      } else {
        const { error } = await supabase.auth.signUp({
          email: values.email,
          password: values.password,
          options: {
            data: {
              full_name: values.full_name,
            },
            emailRedirectTo: `${window.location.origin}/auth/callback?next=/dashboard`,
          },
        });
        if (error) throw error;
        setMessage('Account created. Check your email if confirmation is required, then log in.');
        router.push('/login');
      }
    } catch (error) {
      setMessage(error.message || 'Could not continue');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="page-wrap min-h-screen items-center justify-center">
      <section className="panel mx-auto w-full max-w-md p-6 sm:p-8">
        <div className="mb-6 text-center">
          <div className="text-xs uppercase tracking-[0.25em] text-sky-500">KL Fusion Hub</div>
          <h1 className="mt-2 text-3xl font-bold">{title}</h1>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
            Mobile-first multi-business operating system for POS, invoicing, inventory, suppliers and reports.
          </p>
        </div>

        <form className="grid gap-4" onSubmit={submit}>
          {!isLogin ? (
            <TextField
              label="Full name"
              value={values.full_name}
              onChange={(e) => setValues((current) => ({ ...current, full_name: e.target.value }))}
              placeholder="Jane Doe"
            />
          ) : null}
          <TextField
            label="Email"
            type="email"
            value={values.email}
            onChange={(e) => setValues((current) => ({ ...current, email: e.target.value }))}
            placeholder="you@company.com"
            autoComplete="email"
          />
          <TextField
            label="Password"
            type="password"
            value={values.password}
            onChange={(e) => setValues((current) => ({ ...current, password: e.target.value }))}
            placeholder="••••••••"
            autoComplete={isLogin ? 'current-password' : 'new-password'}
          />

          {message ? (
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-3 text-sm text-slate-600 dark:border-slate-800 dark:bg-slate-950/40 dark:text-slate-300">
              {message}
            </div>
          ) : null}

          <button className="btn-primary w-full" disabled={loading}>
            {loading ? 'Please wait...' : isLogin ? 'Sign in' : 'Create account'}
          </button>
        </form>

        <div className="mt-6 text-center text-sm text-slate-500 dark:text-slate-400">
          {isLogin ? (
            <>
              No account yet? <Link className="font-semibold text-sky-600" href="/register">Create one</Link>
            </>
          ) : (
            <>
              Already have an account? <Link className="font-semibold text-sky-600" href="/login">Sign in</Link>
            </>
          )}
        </div>
      </section>
    </main>
  );
}
