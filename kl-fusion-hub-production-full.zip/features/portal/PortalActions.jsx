'use client';

import { useState } from 'react';

export default function PortalActions({ token, documentId, documentType }) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');

  async function respond(decision) {
    setBusy(true);
    setMessage('');
    const response = await fetch('/api/portal/respond', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, decision }),
    });
    const data = await response.json();
    if (!response.ok) {
      setMessage(data.error || 'Could not update quote');
      setBusy(false);
      return;
    }
    location.reload();
  }

  return (
    <div className="flex flex-wrap gap-3">
      <a className="btn-primary" href={`/api/documents/${documentId}/pdf`} target="_blank" rel="noreferrer">Open PDF</a>
      {documentType === 'quote' ? (
        <>
          <button className="btn-secondary" disabled={busy} onClick={() => respond('accepted')}>Accept quote</button>
          <button className="btn-danger" disabled={busy} onClick={() => respond('declined')}>Decline quote</button>
        </>
      ) : null}
      {message ? <div className="w-full rounded-2xl border p-3 text-sm">{message}</div> : null}
    </div>
  );
}
