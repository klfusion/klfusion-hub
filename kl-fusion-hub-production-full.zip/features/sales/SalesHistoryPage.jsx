'use client';

import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/browser';
import { useApp } from '@/components/BusinessProvider';
import SectionCard from '@/components/SectionCard';
import DataGrid from '@/components/DataGrid';
import ModalSheet from '@/components/ModalSheet';
import { SelectField, TextAreaField, TextField } from '@/components/Field';
import { currency, datetime } from '@/lib/format';

export default function SalesHistoryPage() {
  const supabase = createClient();
  const { currentBusiness, currentLocation, settings } = useApp();
  const [sales, setSales] = useState([]);
  const [refundOpen, setRefundOpen] = useState(false);
  const [refundValues, setRefundValues] = useState({ sale_id: '', refund_method: 'cash', reason: '', items: [] });
  const [message, setMessage] = useState('');

  useEffect(() => {
    load();
  }, [currentBusiness?.id, currentLocation?.id]);

  async function load() {
    if (!currentBusiness?.id) return;
    const { data } = await supabase
      .from('sales')
      .select('*, customer:customers(name), sale_items(*)')
      .eq('business_id', currentBusiness.id)
      .order('created_at', { ascending: false })
      .limit(100);
    const rows = currentLocation?.id ? (data || []).filter((row) => row.location_id === currentLocation.id) : (data || []);
    setSales(rows);
  }

  function startRefund(sale) {
    setRefundValues({
      sale_id: sale.id,
      refund_method: 'cash',
      reason: '',
      items: (sale.sale_items || []).map((item) => ({
        sale_item_id: item.id,
        product_id: item.product_id,
        name: item.name_snapshot,
        quantity: item.quantity,
        refund_quantity: item.quantity,
      })),
    });
    setRefundOpen(true);
    setMessage('');
  }

  async function submitRefund(event) {
    event.preventDefault();
    const response = await fetch(`/api/sales/${refundValues.sale_id}/refund`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(refundValues),
    });
    const data = await response.json();
    if (!response.ok) {
      setMessage(data.error || 'Could not process refund');
      return;
    }
    setRefundOpen(false);
    await load();
  }

  return (
    <div className="page-wrap">
      <SectionCard title="Sales history" description="Completed sales, receipts and refund processing.">
        <DataGrid
          columns={[
            { key: 'sale_number', label: 'Sale #' },
            { key: 'created_at', label: 'Date', render: (row) => datetime(row.created_at) },
            { key: 'customer', label: 'Customer', render: (row) => row.customer?.name || 'Walk-in' },
            { key: 'payment_method', label: 'Payment' },
            { key: 'status', label: 'Status', render: (row) => <span className="badge-muted capitalize">{row.status}</span> },
            { key: 'total', label: 'Total', render: (row) => currency(row.total, settings?.currency_symbol || 'R') },
            {
              key: 'actions',
              label: 'Actions',
              render: (row) => (
                <div className="flex flex-wrap gap-2">
                  <a className="btn-soft" href={`/api/sales/${row.id}/receipt`} target="_blank" rel="noreferrer">Receipt PDF</a>
                  {row.status !== 'refunded' ? <button className="btn-danger" onClick={() => startRefund(row)}>Refund</button> : null}
                </div>
              ),
            },
          ]}
          rows={sales}
        />
      </SectionCard>

      <ModalSheet
        open={refundOpen}
        title="Process refund"
        onClose={() => setRefundOpen(false)}
        footer={
          <div className="flex gap-3">
            <button className="btn-danger" onClick={submitRefund}>Confirm refund</button>
            <button className="btn-soft" onClick={() => setRefundOpen(false)}>Cancel</button>
          </div>
        }
      >
        <form className="grid gap-4" onSubmit={submitRefund}>
          <SelectField
            label="Refund method"
            value={refundValues.refund_method}
            onChange={(e) => setRefundValues((c) => ({ ...c, refund_method: e.target.value }))}
            options={[
              { value: 'cash', label: 'Cash' },
              { value: 'card', label: 'Card' },
              { value: 'eft', label: 'EFT' },
            ]}
          />
          <TextAreaField
            label="Reason"
            value={refundValues.reason}
            onChange={(e) => setRefundValues((c) => ({ ...c, reason: e.target.value }))}
          />
          <div className="grid gap-3">
            {refundValues.items.map((item, index) => (
              <div key={item.sale_item_id} className="rounded-2xl border p-3">
                <div className="font-medium">{item.name}</div>
                <div className="mt-2">
                  <TextField
                    label="Refund quantity"
                    type="number"
                    value={item.refund_quantity}
                    onChange={(e) => setRefundValues((c) => ({
                      ...c,
                      items: c.items.map((entry, i) => i === index ? { ...entry, refund_quantity: Number(e.target.value) } : entry),
                    }))}
                  />
                </div>
              </div>
            ))}
          </div>
          {message ? <div className="rounded-2xl border p-3 text-sm">{message}</div> : null}
        </form>
      </ModalSheet>
    </div>
  );
}
