'use client';

import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/browser';
import { useApp } from '@/components/BusinessProvider';
import SectionCard from '@/components/SectionCard';
import DataGrid from '@/components/DataGrid';
import ModalSheet from '@/components/ModalSheet';
import { SelectField, TextAreaField, TextField } from '@/components/Field';
import { shortDate } from '@/lib/format';

export default function TransfersPage() {
  const supabase = createClient();
  const { currentBusiness, currentLocation, locations } = useApp();
  const [rows, setRows] = useState([]);
  const [products, setProducts] = useState([]);
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [draft, setDraft] = useState({
    from_location_id: '',
    to_location_id: '',
    notes: '',
    items: [{ product_id: '', quantity: 1 }],
  });

  useEffect(() => {
    load();
  }, [currentBusiness?.id]);

  async function load() {
    if (!currentBusiness?.id) return;
    const [{ data: transferRows }, { data: productRows }] = await Promise.all([
      supabase.from('transfer_orders').select('*').eq('business_id', currentBusiness.id).order('created_at', { ascending: false }),
      supabase.from('products').select('id, name').eq('business_id', currentBusiness.id).eq('is_active', true).order('name'),
    ]);
    setRows(transferRows || []);
    setProducts(productRows || []);
    if (currentLocation?.id && !draft.from_location_id) {
      setDraft((c) => ({ ...c, from_location_id: currentLocation.id }));
    }
  }

  function addLine() {
    setDraft((c) => ({ ...c, items: [...c.items, { product_id: '', quantity: 1 }] }));
  }

  function updateItem(index, updates) {
    setDraft((c) => ({ ...c, items: c.items.map((item, i) => i === index ? { ...item, ...updates } : item) }));
  }

  async function save(event) {
    event.preventDefault();
    setMessage('');
    const { data: order, error } = await supabase
      .from('transfer_orders')
      .insert({
        business_id: currentBusiness.id,
        from_location_id: draft.from_location_id,
        to_location_id: draft.to_location_id,
        notes: draft.notes,
        status: 'draft',
      })
      .select('*')
      .single();

    if (error) {
      setMessage(error.message || 'Could not create transfer');
      return;
    }

    const items = draft.items.map((item) => {
      const product = products.find((row) => row.id === item.product_id);
      return {
        transfer_order_id: order.id,
        product_id: item.product_id,
        name_snapshot: product?.name || '',
        quantity: Number(item.quantity || 0),
      };
    });

    const { error: itemError } = await supabase.from('transfer_order_items').insert(items);
    if (itemError) {
      setMessage(itemError.message || 'Could not save transfer lines');
      return;
    }

    setOpen(false);
    setDraft({ from_location_id: currentLocation?.id || '', to_location_id: '', notes: '', items: [{ product_id: '', quantity: 1 }] });
    await load();
  }

  async function complete(row) {
    const response = await fetch('/api/transfers/receive', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ transfer_order_id: row.id }),
    });
    const data = await response.json();
    if (!response.ok) {
      setMessage(data.error || 'Could not complete transfer');
      return;
    }
    await load();
  }

  return (
    <div className="page-wrap">
      <SectionCard
        title="Stock transfers"
        description="Transfer inventory between business locations or warehouses."
        actions={<button className="btn-primary" onClick={() => setOpen(true)}>New transfer</button>}
      >
        {message ? <div className="mb-4 rounded-2xl border p-3 text-sm">{message}</div> : null}
        <DataGrid
          columns={[
            { key: 'number', label: 'Transfer #' },
            { key: 'from_location_id', label: 'From', render: (row) => locations.find((item) => item.id === row.from_location_id)?.name || '—' },
            { key: 'to_location_id', label: 'To', render: (row) => locations.find((item) => item.id === row.to_location_id)?.name || '—' },
            { key: 'status', label: 'Status', render: (row) => <span className="badge-muted capitalize">{row.status}</span> },
            { key: 'created_at', label: 'Created', render: (row) => shortDate(row.created_at) },
            { key: 'actions', label: 'Actions', render: (row) => row.status !== 'received' ? <button className="btn-soft" onClick={() => complete(row)}>Complete</button> : <span className="badge-success">Completed</span> },
          ]}
          rows={rows}
        />
      </SectionCard>

      <ModalSheet
        open={open}
        title="New transfer"
        onClose={() => setOpen(false)}
        footer={
          <div className="flex gap-3">
            <button className="btn-primary" onClick={save}>Save transfer</button>
            <button className="btn-soft" onClick={() => setOpen(false)}>Cancel</button>
          </div>
        }
      >
        <form className="grid gap-4" onSubmit={save}>
          <div className="grid gap-4 sm:grid-cols-2">
            <SelectField
              label="From location"
              value={draft.from_location_id}
              onChange={(e) => setDraft((c) => ({ ...c, from_location_id: e.target.value }))}
              options={locations.map((item) => ({ value: item.id, label: item.name }))}
            />
            <SelectField
              label="To location"
              value={draft.to_location_id}
              onChange={(e) => setDraft((c) => ({ ...c, to_location_id: e.target.value }))}
              options={locations.filter((item) => item.id !== draft.from_location_id).map((item) => ({ value: item.id, label: item.name }))}
            />
          </div>
          {draft.items.map((item, index) => (
            <div key={index} className="rounded-2xl border p-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <SelectField
                  label="Product"
                  value={item.product_id}
                  onChange={(e) => updateItem(index, { product_id: e.target.value })}
                  options={products.map((row) => ({ value: row.id, label: row.name }))}
                />
                <TextField label="Quantity" type="number" value={item.quantity} onChange={(e) => updateItem(index, { quantity: e.target.value })} />
              </div>
            </div>
          ))}
          <button className="btn-soft" type="button" onClick={addLine}>Add line</button>
          <TextAreaField label="Notes" value={draft.notes} onChange={(e) => setDraft((c) => ({ ...c, notes: e.target.value }))} />
        </form>
      </ModalSheet>
    </div>
  );
}
