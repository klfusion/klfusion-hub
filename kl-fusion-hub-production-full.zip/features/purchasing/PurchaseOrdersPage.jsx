'use client';

import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/browser';
import { useApp } from '@/components/BusinessProvider';
import SectionCard from '@/components/SectionCard';
import DataGrid from '@/components/DataGrid';
import ModalSheet from '@/components/ModalSheet';
import { SelectField, TextAreaField, TextField } from '@/components/Field';
import { currency, shortDate } from '@/lib/format';

export default function PurchaseOrdersPage() {
  const supabase = createClient();
  const { currentBusiness, currentLocation, settings } = useApp();
  const [orders, setOrders] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [products, setProducts] = useState([]);
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [draft, setDraft] = useState({
    supplier_id: '',
    expected_at: new Date().toISOString().slice(0, 10),
    notes: '',
    items: [{ product_id: '', quantity: 1, unit_cost: 0 }],
  });

  useEffect(() => {
    load();
  }, [currentBusiness?.id, currentLocation?.id]);

  async function load() {
    if (!currentBusiness?.id) return;
    const [{ data: orderRows }, { data: supplierRows }, { data: productRows }] = await Promise.all([
      supabase
        .from('purchase_orders')
        .select('*, supplier:suppliers(name)')
        .eq('business_id', currentBusiness.id)
        .order('created_at', { ascending: false }),
      supabase.from('suppliers').select('id, name').eq('business_id', currentBusiness.id).eq('is_active', true).order('name'),
      supabase.from('products').select('id, name, cost').eq('business_id', currentBusiness.id).eq('is_active', true).order('name'),
    ]);
    setOrders(orderRows || []);
    setSuppliers(supplierRows || []);
    setProducts(productRows || []);
  }

  function addItem() {
    setDraft((c) => ({ ...c, items: [...c.items, { product_id: '', quantity: 1, unit_cost: 0 }] }));
  }

  function updateItem(index, updates) {
    setDraft((c) => ({ ...c, items: c.items.map((item, i) => i === index ? { ...item, ...updates } : item) }));
  }

  async function save(event) {
    event.preventDefault();
    setMessage('');
    const totals = draft.items.reduce((acc, item) => {
      const line = Number(item.quantity || 0) * Number(item.unit_cost || 0);
      return { subtotal: acc.subtotal + line, total: acc.total + line };
    }, { subtotal: 0, total: 0 });

    const { data: order, error } = await supabase
      .from('purchase_orders')
      .insert({
        business_id: currentBusiness.id,
        location_id: currentLocation?.id || null,
        supplier_id: draft.supplier_id || null,
        expected_at: draft.expected_at,
        notes: draft.notes,
        subtotal: totals.subtotal,
        total: totals.total,
        status: 'ordered',
      })
      .select('*')
      .single();

    if (error) {
      setMessage(error.message || 'Could not create purchase order');
      return;
    }

    const itemRows = draft.items.map((item) => {
      const product = products.find((row) => row.id === item.product_id);
      return {
        purchase_order_id: order.id,
        product_id: item.product_id,
        name_snapshot: product?.name || '',
        quantity: Number(item.quantity || 0),
        unit_cost: Number(item.unit_cost || 0),
        line_total: Number(item.quantity || 0) * Number(item.unit_cost || 0),
      };
    });

    const { error: itemError } = await supabase.from('purchase_order_items').insert(itemRows);
    if (itemError) {
      setMessage(itemError.message || 'Could not save order items');
      return;
    }

    setOpen(false);
    setDraft({
      supplier_id: '',
      expected_at: new Date().toISOString().slice(0, 10),
      notes: '',
      items: [{ product_id: '', quantity: 1, unit_cost: 0 }],
    });
    await load();
  }

  async function receive(order) {
    const response = await fetch('/api/purchase-orders/receive', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ purchase_order_id: order.id }),
    });
    const data = await response.json();
    if (!response.ok) {
      setMessage(data.error || 'Could not receive purchase order');
      return;
    }
    await load();
  }

  return (
    <div className="page-wrap">
      <SectionCard
        title="Purchase orders"
        description="Supplier ordering, stock receiving, vendor spend and replenishment."
        actions={<button className="btn-primary" onClick={() => setOpen(true)}>New purchase order</button>}
      >
        {message ? <div className="mb-4 rounded-2xl border p-3 text-sm">{message}</div> : null}
        <DataGrid
          columns={[
            { key: 'number', label: 'PO #' },
            { key: 'supplier', label: 'Supplier', render: (row) => row.supplier?.name || '—' },
            { key: 'expected_at', label: 'Expected', render: (row) => shortDate(row.expected_at) },
            { key: 'status', label: 'Status', render: (row) => <span className="badge-muted capitalize">{row.status}</span> },
            { key: 'total', label: 'Total', render: (row) => currency(row.total, settings?.currency_symbol || 'R') },
            {
              key: 'actions',
              label: 'Actions',
              render: (row) => row.status !== 'received'
                ? <button className="btn-soft" onClick={() => receive(row)}>Receive stock</button>
                : <span className="badge-success">Received</span>,
            },
          ]}
          rows={orders}
        />
      </SectionCard>

      <ModalSheet
        open={open}
        title="New purchase order"
        onClose={() => setOpen(false)}
        footer={
          <div className="flex gap-3">
            <button className="btn-primary" onClick={save}>Save order</button>
            <button className="btn-soft" onClick={() => setOpen(false)}>Cancel</button>
          </div>
        }
      >
        <form className="grid gap-4" onSubmit={save}>
          <div className="grid gap-4 sm:grid-cols-2">
            <SelectField
              label="Supplier"
              value={draft.supplier_id}
              onChange={(e) => setDraft((c) => ({ ...c, supplier_id: e.target.value }))}
              options={suppliers.map((item) => ({ value: item.id, label: item.name }))}
            />
            <TextField
              label="Expected date"
              type="date"
              value={draft.expected_at}
              onChange={(e) => setDraft((c) => ({ ...c, expected_at: e.target.value }))}
            />
          </div>

          {draft.items.map((item, index) => (
            <div key={index} className="rounded-2xl border p-4">
              <div className="grid gap-4 sm:grid-cols-3">
                <SelectField
                  label="Product"
                  value={item.product_id}
                  onChange={(e) => {
                    const product = products.find((row) => row.id === e.target.value);
                    updateItem(index, { product_id: e.target.value, unit_cost: Number(product?.cost || 0) });
                  }}
                  options={products.map((row) => ({ value: row.id, label: row.name }))}
                />
                <TextField label="Quantity" type="number" value={item.quantity} onChange={(e) => updateItem(index, { quantity: e.target.value })} />
                <TextField label="Unit cost" type="number" value={item.unit_cost} onChange={(e) => updateItem(index, { unit_cost: e.target.value })} />
              </div>
            </div>
          ))}
          <div><button className="btn-soft" type="button" onClick={addItem}>Add line</button></div>
          <TextAreaField label="Notes" value={draft.notes} onChange={(e) => setDraft((c) => ({ ...c, notes: e.target.value }))} />
        </form>
      </ModalSheet>
    </div>
  );
}
