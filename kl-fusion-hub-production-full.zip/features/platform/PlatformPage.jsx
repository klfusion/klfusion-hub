'use client';

import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/browser';
import { useApp } from '@/components/BusinessProvider';
import SectionCard from '@/components/SectionCard';
import DataGrid from '@/components/DataGrid';
import { datetime } from '@/lib/format';

export default function PlatformPage() {
  const supabase = createClient();
  const { profile } = useApp();
  const [businesses, setBusinesses] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    async function load() {
      if (profile?.role_global !== 'platform_admin') return;
      const { data } = await supabase.from('businesses').select('*').order('created_at', { ascending: false });
      setBusinesses(data || []);
    }
    load();
  }, [profile?.role_global]);

  async function toggleBusiness(row) {
    const { error } = await supabase.from('businesses').update({ is_active: !row.is_active }).eq('id', row.id);
    if (error) {
      setMessage(error.message || 'Could not update business');
      return;
    }
    setBusinesses((current) => current.map((item) => item.id === row.id ? { ...item, is_active: !item.is_active } : item));
  }

  if (profile?.role_global !== 'platform_admin') {
    return (
      <div className="page-wrap">
        <SectionCard title="Platform admin" description="Restricted to platform administrators.">
          <div className="rounded-2xl border border-dashed p-4 text-sm text-slate-500">You are not a platform admin.</div>
        </SectionCard>
      </div>
    );
  }

  return (
    <div className="page-wrap">
      <SectionCard title="Platform businesses" description="Tenant overview, activation control and top-level governance.">
        {message ? <div className="mb-4 rounded-2xl border p-3 text-sm">{message}</div> : null}
        <DataGrid
          columns={[
            { key: 'name', label: 'Business' },
            { key: 'slug', label: 'Slug' },
            { key: 'owner_id', label: 'Owner ID' },
            { key: 'created_at', label: 'Created', render: (row) => datetime(row.created_at) },
            { key: 'state', label: 'State', render: (row) => row.is_active ? <span className="badge-success">Active</span> : <span className="badge-warn">Inactive</span> },
            { key: 'actions', label: 'Actions', render: (row) => <button className="btn-soft" onClick={() => toggleBusiness(row)}>{row.is_active ? 'Deactivate' : 'Activate'}</button> },
          ]}
          rows={businesses}
        />
      </SectionCard>
    </div>
  );
}
