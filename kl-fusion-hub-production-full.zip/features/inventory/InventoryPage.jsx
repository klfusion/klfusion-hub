'use client';

import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/browser';
import { useApp } from '@/components/BusinessProvider';
import SectionCard from '@/components/SectionCard';
import DataGrid from '@/components/DataGrid';
import ModalSheet from '@/components/ModalSheet';
import { SelectField, TextAreaField, TextField } from '@/components/Field';
import { shortDate } from '@/lib/format';

export default function InventoryPage() {
  const supabase = createClient();
  const { currentBusiness, currentLocation } = useApp();
  const [balances, setBalances] = useState([]);
  const [movements, setMovements] = useState([]);
  const [products, setProducts] = useState([]);
  const [adjustOpen, setAdjustOpen] = useState(false);
  const [adjustment, setAdjustment] = useState({ product_id: '', quantity_delta: 0, note: '' });
  const [message, setMessage] = useState('');

  useEffect(() => {
    load();
  }, [currentBusiness?.id, currentLocation?.id]);

  async function load() {
    if (!currentBusiness?.id || !currentLocation?.id) return;

    const [{ data: balanceRows }, { data: movementRows }, { data: productRows }] = await Promise.all([
      supabase
        .from('inventory_balances')
        .select('*, product:products(name, sku, barcode, low_stock_point)')
        .eq('business_id', currentBusiness.id)
        .eq('location_id', currentLocation.id)
        .order('updated_at', { ascending: false }),
      supabase
        .from('inventory_movements')
        .select('*, product:products(name)')
        .eq('business_id', currentBusiness.id)
        .eq('location_id', currentLocation.id)
        .order('created_at', { ascending: false })
        .limit(25),
      supabase
        .from('products')
        .select('id, name')
        .eq('business_id', currentBusiness.id)
        .eq('is_active', true)
        .order('name'),
    ]);

    setBalances(balanceRows || []);
    setMovements(movementRows || []);
    setProducts(productRows || []);
  }

  async function submitAdjustment(event) {
    event.preventDefault();
    setMessage('');
    const response = await fetch('/api/inventory/adjust', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        business_id: currentBusiness.id,
        location_id: currentLocation.id,
        ...adjustment,
      }),
    });

    const data = await response.json();
    if (!response.ok) {
      setMessage(data.error || 'Could not adjust stock');
      return;
    }

    setAdjustment({ product_id: '', quantity_delta: 0, note: '' });
    setAdjustOpen(false);
    await load();
  }

  return (
    <div className="page-wrap">
      <SectionCard
        title="Inventory"
        description="View location balances, recent stock movements and run manual adjustments."
        actions={<button className="btn-primary" onClick={() => setAdjustOpen(true)}>Stock adjustment</button>}
      >
        <DataGrid
          columns={[
            { key: 'product', label: 'Product', render: (row) => row.product?.name || '—' },
            { key: 'sku', label: 'SKU', render: (row) => row.product?.sku || '—' },
            { key: 'barcode', label: 'Barcode', render: (row) => row.product?.barcode || '—' },
            { key: 'quantity_on_hand', label: 'On hand' },
            { key: 'reorder_point', label: 'Reorder point' },
            { key: 'state', label: 'State', render: (row) => Number(row.quantity_on_hand) <= Number(row.reorder_point || row.product?.low_stock_point || 0) ? <span className="badge-warn">Low</span> : <span className="badge-success">Healthy</span> },
          ]}
          rows={balances}
        />
      </SectionCard>

      <SectionCard title="Recent movements" description="Sales, refunds, receiving, transfers and manual adjustments all land here.">
        <DataGrid
          columns={[
            { key: 'created_at', label: 'Date', render: (row) => shortDate(row.created_at) },
            { key: 'product', label: 'Product', render: (row) => row.product?.name || '—' },
            { key: 'movement_type', label: 'Type' },
            { key: 'quantity_delta', label: 'Delta' },
            { key: 'note', label: 'Note' },
          ]}
          rows={movements}
        />
      </SectionCard>

      <ModalSheet
        open={adjustOpen}
        title="Adjust inventory"
        onClose={() => setAdjustOpen(false)}
        footer={
          <div className="flex gap-3">
            <button className="btn-primary" onClick={submitAdjustment}>Save adjustment</button>
            <button className="btn-soft" onClick={() => setAdjustOpen(false)}>Cancel</button>
          </div>
        }
      >
        <form className="grid gap-4" onSubmit={submitAdjustment}>
          <SelectField
            label="Product"
            value={adjustment.product_id}
            onChange={(e) => setAdjustment((c) => ({ ...c, product_id: e.target.value }))}
            options={products.map((item) => ({ value: item.id, label: item.name }))}
          />
          <TextField
            label="Quantity delta"
            type="number"
            value={adjustment.quantity_delta}
            onChange={(e) => setAdjustment((c) => ({ ...c, quantity_delta: e.target.value }))}
            placeholder="Use negative for stock down"
          />
          <TextAreaField
            label="Reason"
            value={adjustment.note}
            onChange={(e) => setAdjustment((c) => ({ ...c, note: e.target.value }))}
          />
          {message ? <div className="rounded-2xl border p-3 text-sm">{message}</div> : null}
        </form>
      </ModalSheet>
    </div>
  );
}
