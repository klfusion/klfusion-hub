'use client';

import { useEffect, useMemo, useState } from 'react';
import { createClient } from '@/lib/supabase/browser';
import { useApp } from '@/components/BusinessProvider';
import SectionCard from '@/components/SectionCard';
import DataGrid from '@/components/DataGrid';
import ModalSheet from '@/components/ModalSheet';
import { CheckboxField, SelectField, TextAreaField, TextField } from '@/components/Field';
import { currency, shortDate } from '@/lib/format';

function renderField(field, value, onChange) {
  const commonProps = {
    value: field.type === 'checkbox' ? undefined : value ?? '',
    onChange: (event) => {
      if (field.type === 'checkbox') {
        onChange(event.target.checked);
      } else {
        onChange(event.target.value);
      }
    },
    placeholder: field.placeholder,
  };

  if (field.type === 'textarea') {
    return <TextAreaField label={field.label} {...commonProps} />;
  }

  if (field.type === 'select') {
    return <SelectField label={field.label} options={field.options || []} {...commonProps} />;
  }

  if (field.type === 'checkbox') {
    return <CheckboxField label={field.label} checked={Boolean(value)} onChange={(e) => onChange(e.target.checked)} />;
  }

  return <TextField label={field.label} type={field.type || 'text'} {...commonProps} />;
}

export default function CrudPage({
  title,
  description,
  table,
  fields,
  columns,
  query = '*',
  defaultValues = {},
  transformBeforeSave = (values) => values,
  transformRows = (rows) => rows,
  orderBy = 'created_at',
}) {
  const supabase = createClient();
  const { currentBusiness } = useApp();
  const [rows, setRows] = useState([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [values, setValues] = useState(defaultValues);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  const mappedColumns = useMemo(() => columns.map((column) => {
    if (column.type === 'money') {
      return {
        key: column.key,
        label: column.label,
        render: (row) => currency(row[column.key]),
      };
    }
    if (column.type === 'date') {
      return {
        key: column.key,
        label: column.label,
        render: (row) => shortDate(row[column.key]),
      };
    }
    return column;
  }), [columns]);

  useEffect(() => {
    load();
  }, [currentBusiness?.id]);

  async function load() {
    if (!currentBusiness?.id) return;
    const { data } = await supabase
      .from(table)
      .select(query)
      .eq('business_id', currentBusiness.id)
      .order(orderBy, { ascending: false });
    setRows(transformRows(data || []));
  }

  function openCreate() {
    setEditing(null);
    setValues(defaultValues);
    setMessage('');
    setOpen(true);
  }

  function openEdit(row) {
    setEditing(row);
    setValues({ ...defaultValues, ...row });
    setMessage('');
    setOpen(true);
  }

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setMessage('');

    try {
      const payload = transformBeforeSave({
        ...values,
        business_id: currentBusiness.id,
      });

      if (editing?.id) {
        const { error } = await supabase.from(table).update(payload).eq('id', editing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from(table).insert(payload);
        if (error) throw error;
      }

      setOpen(false);
      await load();
    } catch (error) {
      setMessage(error.message || 'Could not save');
    } finally {
      setBusy(false);
    }
  }

  async function remove(row) {
    if (!confirm(`Delete ${row.name || row.description || 'this record'}?`)) return;
    const { error } = await supabase.from(table).delete().eq('id', row.id);
    if (error) {
      setMessage(error.message || 'Could not delete');
      return;
    }
    await load();
  }

  const rowsWithActions = rows.map((row) => ({
    ...row,
    __actions: row,
  }));

  return (
    <div className="page-wrap">
      <SectionCard
        title={title}
        description={description}
        actions={<button className="btn-primary" onClick={openCreate}>Add new</button>}
      >
        {message ? <div className="mb-4 rounded-2xl border p-3 text-sm">{message}</div> : null}
        <DataGrid
          columns={[
            ...mappedColumns,
            {
              key: '__actions',
              label: 'Actions',
              render: (row) => (
                <div className="flex flex-wrap gap-2">
                  <button className="btn-soft" onClick={() => openEdit(row)}>Edit</button>
                  <button className="btn-danger" onClick={() => remove(row)}>Delete</button>
                </div>
              ),
            },
          ]}
          rows={rowsWithActions}
        />
      </SectionCard>

      <ModalSheet
        open={open}
        title={editing ? `Edit ${title}` : `New ${title}`}
        onClose={() => setOpen(false)}
        footer={
          <div className="flex flex-wrap gap-3">
            <button className="btn-primary" onClick={submit} disabled={busy}>
              {busy ? 'Saving...' : 'Save'}
            </button>
            <button className="btn-soft" onClick={() => setOpen(false)}>Cancel</button>
          </div>
        }
      >
        <form className="grid gap-4 sm:grid-cols-2" onSubmit={submit}>
          {fields.map((field) => (
            <div key={field.name} className={field.span === 2 ? 'sm:col-span-2' : ''}>
              {renderField(field, values[field.name], (next) => setValues((current) => ({ ...current, [field.name]: next })))}
            </div>
          ))}
          {message ? <div className="sm:col-span-2 rounded-2xl border p-3 text-sm">{message}</div> : null}
        </form>
      </ModalSheet>
    </div>
  );
}
