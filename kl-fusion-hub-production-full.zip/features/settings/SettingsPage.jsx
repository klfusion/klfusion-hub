'use client';

import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/browser';
import { useApp } from '@/components/BusinessProvider';
import SectionCard from '@/components/SectionCard';
import { CheckboxField, TextAreaField, TextField } from '@/components/Field';

export default function SettingsPage() {
  const supabase = createClient();
  const { currentBusiness, settings, refreshBusinessMeta } = useApp();
  const [values, setValues] = useState({});
  const [message, setMessage] = useState('');

  useEffect(() => {
    setValues({
      business_name: settings?.business_name || currentBusiness?.name || '',
      tagline: settings?.tagline || '',
      currency_code: settings?.currency_code || 'ZAR',
      currency_symbol: settings?.currency_symbol || 'R',
      vat_enabled: settings?.vat_enabled ?? true,
      vat_rate: settings?.vat_rate ?? 15,
      logo_url: settings?.logo_url || '',
      address: settings?.address || '',
      email: settings?.email || '',
      mobile: settings?.mobile || '',
      website: settings?.website || '',
      tax_number: settings?.tax_number || '',
      invoice_prefix: settings?.invoice_prefix || 'INV',
      quote_prefix: settings?.quote_prefix || 'QTE',
      receipt_prefix: settings?.receipt_prefix || 'SALE',
      purchase_order_prefix: settings?.purchase_order_prefix || 'PO',
      terms_and_conditions: settings?.terms_and_conditions || '',
      delivery_details: settings?.delivery_details || '',
      bank_name: settings?.bank_name || '',
      account_holder: settings?.account_holder || '',
      account_number: settings?.account_number || '',
      bank_code: settings?.bank_code || '',
    });
  }, [settings, currentBusiness?.name]);

  async function save(event) {
    event.preventDefault();
    const { error } = await supabase.from('business_settings').upsert({
      business_id: currentBusiness.id,
      ...values,
    });
    if (error) {
      setMessage(error.message || 'Could not save settings');
      return;
    }
    setMessage('Settings saved.');
    await refreshBusinessMeta();
  }

  return (
    <div className="page-wrap">
      <SectionCard title="Business settings" description="Branding, numbering, tax, contact details and invoice defaults.">
        <form className="grid gap-4 sm:grid-cols-2" onSubmit={save}>
          <TextField label="Business name" value={values.business_name || ''} onChange={(e) => setValues((c) => ({ ...c, business_name: e.target.value }))} />
          <TextField label="Tagline" value={values.tagline || ''} onChange={(e) => setValues((c) => ({ ...c, tagline: e.target.value }))} />
          <TextField label="Currency code" value={values.currency_code || ''} onChange={(e) => setValues((c) => ({ ...c, currency_code: e.target.value }))} />
          <TextField label="Currency symbol" value={values.currency_symbol || ''} onChange={(e) => setValues((c) => ({ ...c, currency_symbol: e.target.value }))} />
          <TextField label="VAT rate" type="number" value={values.vat_rate || 0} onChange={(e) => setValues((c) => ({ ...c, vat_rate: e.target.value }))} />
          <CheckboxField label="VAT enabled" checked={Boolean(values.vat_enabled)} onChange={(e) => setValues((c) => ({ ...c, vat_enabled: e.target.checked }))} />
          <TextField label="Logo URL" value={values.logo_url || ''} onChange={(e) => setValues((c) => ({ ...c, logo_url: e.target.value }))} />
          <TextField label="Tax number" value={values.tax_number || ''} onChange={(e) => setValues((c) => ({ ...c, tax_number: e.target.value }))} />
          <TextField label="Email" value={values.email || ''} onChange={(e) => setValues((c) => ({ ...c, email: e.target.value }))} />
          <TextField label="Mobile" value={values.mobile || ''} onChange={(e) => setValues((c) => ({ ...c, mobile: e.target.value }))} />
          <TextField label="Website" value={values.website || ''} onChange={(e) => setValues((c) => ({ ...c, website: e.target.value }))} />
          <TextField label="Address" value={values.address || ''} onChange={(e) => setValues((c) => ({ ...c, address: e.target.value }))} />
          <TextField label="Invoice prefix" value={values.invoice_prefix || ''} onChange={(e) => setValues((c) => ({ ...c, invoice_prefix: e.target.value }))} />
          <TextField label="Quote prefix" value={values.quote_prefix || ''} onChange={(e) => setValues((c) => ({ ...c, quote_prefix: e.target.value }))} />
          <TextField label="Receipt prefix" value={values.receipt_prefix || ''} onChange={(e) => setValues((c) => ({ ...c, receipt_prefix: e.target.value }))} />
          <TextField label="PO prefix" value={values.purchase_order_prefix || ''} onChange={(e) => setValues((c) => ({ ...c, purchase_order_prefix: e.target.value }))} />
          <TextField label="Bank name" value={values.bank_name || ''} onChange={(e) => setValues((c) => ({ ...c, bank_name: e.target.value }))} />
          <TextField label="Account holder" value={values.account_holder || ''} onChange={(e) => setValues((c) => ({ ...c, account_holder: e.target.value }))} />
          <TextField label="Account number" value={values.account_number || ''} onChange={(e) => setValues((c) => ({ ...c, account_number: e.target.value }))} />
          <TextField label="Bank code" value={values.bank_code || ''} onChange={(e) => setValues((c) => ({ ...c, bank_code: e.target.value }))} />
          <div className="sm:col-span-2">
            <TextAreaField label="Terms and conditions" value={values.terms_and_conditions || ''} onChange={(e) => setValues((c) => ({ ...c, terms_and_conditions: e.target.value }))} />
          </div>
          <div className="sm:col-span-2">
            <TextAreaField label="Delivery details" value={values.delivery_details || ''} onChange={(e) => setValues((c) => ({ ...c, delivery_details: e.target.value }))} />
          </div>
          <div className="sm:col-span-2 flex gap-3">
            <button className="btn-primary" type="submit">Save settings</button>
          </div>
        </form>
        {message ? <div className="mt-4 rounded-2xl border p-3 text-sm">{message}</div> : null}
      </SectionCard>
    </div>
  );
}
