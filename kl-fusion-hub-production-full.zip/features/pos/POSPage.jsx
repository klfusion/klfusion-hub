'use client';

import { useEffect, useMemo, useState } from 'react';
import { createClient } from '@/lib/supabase/browser';
import { useApp } from '@/components/BusinessProvider';
import SectionCard from '@/components/SectionCard';
import ModalSheet from '@/components/ModalSheet';
import { PAYMENT_METHODS } from '@/lib/constants';
import { SelectField, TextAreaField, TextField } from '@/components/Field';
import { currency } from '@/lib/format';

export default function POSPage() {
  const supabase = createClient();
  const { currentBusiness, currentLocation, settings } = useApp();
  const [products, setProducts] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [search, setSearch] = useState('');
  const [cart, setCart] = useState([]);
  const [tenderOpen, setTenderOpen] = useState(false);
  const [tender, setTender] = useState({ payment_method: 'cash', received_amount: 0, customer_id: '', notes: '' });
  const [message, setMessage] = useState('');
  const [lastSaleId, setLastSaleId] = useState('');

  useEffect(() => {
    load();
  }, [currentBusiness?.id, currentLocation?.id]);

  async function load() {
    if (!currentBusiness?.id) return;

    const [{ data: productRows }, { data: balanceRows }, { data: customerRows }] = await Promise.all([
      supabase
        .from('products')
        .select('*')
        .eq('business_id', currentBusiness.id)
        .eq('is_active', true)
        .order('name'),
      currentLocation?.id
        ? supabase
            .from('inventory_balances')
            .select('product_id, quantity_on_hand')
            .eq('business_id', currentBusiness.id)
            .eq('location_id', currentLocation.id)
        : Promise.resolve({ data: [] }),
      supabase
        .from('customers')
        .select('id, name')
        .eq('business_id', currentBusiness.id)
        .eq('is_active', true)
        .order('name'),
    ]);

    const balanceMap = new Map((balanceRows || []).map((row) => [row.product_id, Number(row.quantity_on_hand)]));
    setProducts((productRows || []).map((row) => ({
      ...row,
      quantity_on_hand: balanceMap.get(row.id) ?? 0,
    })));
    setCustomers(customerRows || []);
  }

  const filteredProducts = useMemo(() => {
    return products.filter((row) => {
      const haystack = `${row.name} ${row.sku || ''} ${row.barcode || ''}`.toLowerCase();
      return haystack.includes(search.toLowerCase());
    });
  }, [products, search]);

  function addToCart(product) {
    setCart((current) => {
      const existing = current.find((item) => item.product_id === product.id);
      if (existing) {
        return current.map((item) => item.product_id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }

      return [
        ...current,
        {
          product_id: product.id,
          name: product.name,
          quantity: 1,
          unit_price: Number(product.price || 0),
          unit_cost: Number(product.cost || 0),
          tax_rate: Number(product.tax_rate || 0),
          quantity_on_hand: Number(product.quantity_on_hand || 0),
        },
      ];
    });
  }

  function changeQty(productId, next) {
    setCart((current) => current
      .map((item) => item.product_id === productId ? { ...item, quantity: Math.max(1, next) } : item)
      .filter((item) => item.quantity > 0));
  }

  function removeItem(productId) {
    setCart((current) => current.filter((item) => item.product_id !== productId));
  }

  const subtotal = cart.reduce((sum, item) => sum + (Number(item.unit_price) * Number(item.quantity)), 0);
  const tax = cart.reduce((sum, item) => sum + (Number(item.unit_price) * Number(item.quantity) * Number(item.tax_rate || 0) / 100), 0);
  const total = subtotal + tax;
  const change = Math.max(0, Number(tender.received_amount || 0) - total);

  async function checkout(event) {
    event.preventDefault();
    setMessage('');

    const response = await fetch('/api/pos/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        business_id: currentBusiness.id,
        location_id: currentLocation?.id || null,
        customer_id: tender.customer_id || null,
        payment_method: tender.payment_method,
        received_amount: Number(tender.received_amount || 0),
        notes: tender.notes,
        items: cart,
      }),
    });

    const data = await response.json();
    if (!response.ok) {
      setMessage(data.error || 'Checkout failed');
      return;
    }

    setLastSaleId(data.sale_id);
    setCart([]);
    setTender({ payment_method: 'cash', received_amount: 0, customer_id: '', notes: '' });
    setTenderOpen(false);
    setMessage('Sale completed successfully.');
    await load();
  }

  return (
    <div className="page-wrap">
      <div className="grid gap-5 xl:grid-cols-[1.5fr_1fr]">
        <SectionCard title="Point of sale" description="Search by name, SKU or barcode. Scanner input works because barcode values are matched in the search box.">
          <div className="mb-4">
            <TextField label="Search products" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Name, SKU or barcode" />
          </div>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {filteredProducts.map((product) => (
              <button
                key={product.id}
                className="rounded-3xl border p-4 text-left transition hover:bg-slate-50 dark:hover:bg-slate-900"
                onClick={() => addToCart(product)}
              >
                <div className="font-semibold">{product.name}</div>
                <div className="mt-1 text-sm text-slate-500">{product.sku || product.barcode || 'No code'}</div>
                <div className="mt-3 flex items-center justify-between text-sm">
                  <span>{currency(product.price, settings?.currency_symbol || 'R')}</span>
                  <span className={Number(product.quantity_on_hand) <= Number(product.low_stock_point || 0) ? 'badge-warn' : 'badge-success'}>
                    {product.quantity_on_hand} in stock
                  </span>
                </div>
              </button>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Cart" description="Tender shortcuts for cash, card, EFT and mixed payment.">
          {!cart.length ? (
            <div className="rounded-2xl border border-dashed p-5 text-sm text-slate-500">Add products to start a sale.</div>
          ) : (
            <div className="grid gap-3">
              {cart.map((item) => (
                <div key={item.product_id} className="rounded-2xl border p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-medium">{item.name}</div>
                      <div className="mt-1 text-sm text-slate-500">{currency(item.unit_price, settings?.currency_symbol || 'R')} each</div>
                    </div>
                    <button className="btn-danger" onClick={() => removeItem(item.product_id)}>Remove</button>
                  </div>
                  <div className="mt-3 flex items-center gap-2">
                    <button className="btn-soft" onClick={() => changeQty(item.product_id, item.quantity - 1)}>-</button>
                    <div className="min-w-12 text-center text-sm font-semibold">{item.quantity}</div>
                    <button className="btn-soft" onClick={() => changeQty(item.product_id, item.quantity + 1)}>+</button>
                    <div className="ml-auto text-sm font-semibold">{currency(item.quantity * item.unit_price, settings?.currency_symbol || 'R')}</div>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="mt-5 grid gap-2 rounded-3xl bg-slate-50 p-4 text-sm dark:bg-slate-900">
            <div className="flex justify-between"><span>Subtotal</span><span>{currency(subtotal, settings?.currency_symbol || 'R')}</span></div>
            <div className="flex justify-between"><span>Tax</span><span>{currency(tax, settings?.currency_symbol || 'R')}</span></div>
            <div className="flex justify-between text-lg font-semibold"><span>Total</span><span>{currency(total, settings?.currency_symbol || 'R')}</span></div>
          </div>

          <div className="mt-4 grid gap-2">
            {PAYMENT_METHODS.map((method) => (
              <button
                key={method.value}
                className="btn-primary w-full"
                onClick={() => {
                  setTender((current) => ({ ...current, payment_method: method.value, received_amount: total }));
                  setTenderOpen(true);
                }}
                disabled={!cart.length}
              >
                Pay {method.label}
              </button>
            ))}
          </div>

          {lastSaleId ? (
            <div className="mt-4 flex flex-wrap gap-3">
              <a className="btn-soft" href={`/api/sales/${lastSaleId}/receipt`} target="_blank" rel="noreferrer">Receipt PDF</a>
              <a className="btn-soft" href="/sales">Open sales history</a>
            </div>
          ) : null}

          {message ? <div className="mt-4 rounded-2xl border p-3 text-sm">{message}</div> : null}
        </SectionCard>
      </div>

      <ModalSheet
        open={tenderOpen}
        title="Complete sale"
        onClose={() => setTenderOpen(false)}
        footer={
          <div className="flex gap-3">
            <button className="btn-primary" onClick={checkout}>Confirm payment</button>
            <button className="btn-soft" onClick={() => setTenderOpen(false)}>Cancel</button>
          </div>
        }
      >
        <form className="grid gap-4" onSubmit={checkout}>
          <SelectField
            label="Customer"
            value={tender.customer_id}
            onChange={(e) => setTender((current) => ({ ...current, customer_id: e.target.value }))}
            options={customers.map((item) => ({ value: item.id, label: item.name }))}
          />
          <SelectField
            label="Payment method"
            value={tender.payment_method}
            onChange={(e) => setTender((current) => ({ ...current, payment_method: e.target.value }))}
            options={PAYMENT_METHODS}
          />
          <TextField
            label="Amount received"
            type="number"
            value={tender.received_amount}
            onChange={(e) => setTender((current) => ({ ...current, received_amount: e.target.value }))}
          />
          <div className="rounded-2xl border p-4 text-sm">
            <div className="flex justify-between"><span>Total due</span><span>{currency(total, settings?.currency_symbol || 'R')}</span></div>
            <div className="mt-2 flex justify-between"><span>Change due</span><span>{currency(change, settings?.currency_symbol || 'R')}</span></div>
          </div>
          <TextAreaField
            label="Notes"
            value={tender.notes}
            onChange={(e) => setTender((current) => ({ ...current, notes: e.target.value }))}
          />
        </form>
      </ModalSheet>
    </div>
  );
}
