'use client';

import { useEffect, useMemo, useState } from 'react';
import { createClient } from '@/lib/supabase/browser';
import { useApp } from '@/components/BusinessProvider';
import SectionCard from '@/components/SectionCard';
import DataGrid from '@/components/DataGrid';
import ModalSheet from '@/components/ModalSheet';
import { CheckboxField, SelectField, TextAreaField, TextField } from '@/components/Field';
import { currency } from '@/lib/format';

const emptyForm = {
  name: '',
  sku: '',
  barcode: '',
  category_id: '',
  supplier_id: '',
  description: '',
  unit: 'each',
  type: 'stocked',
  price: 0,
  cost: 0,
  tax_rate: 15,
  low_stock_point: 5,
  track_inventory: true,
  opening_stock: 0,
  is_active: true,
};

export default function ProductsPage() {
  const supabase = createClient();
  const { currentBusiness, currentLocation, settings } = useApp();
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [values, setValues] = useState(emptyForm);
  const [search, setSearch] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    load();
  }, [currentBusiness?.id, currentLocation?.id]);

  async function load() {
    if (!currentBusiness?.id) return;

    const [{ data: productRows }, { data: categoryRows }, { data: supplierRows }, { data: balanceRows }] = await Promise.all([
      supabase
        .from('products')
        .select('*, category:categories(name), supplier:suppliers(name)')
        .eq('business_id', currentBusiness.id)
        .order('created_at', { ascending: false }),
      supabase
        .from('categories')
        .select('id, name')
        .eq('business_id', currentBusiness.id)
        .eq('is_active', true)
        .order('name'),
      supabase
        .from('suppliers')
        .select('id, name')
        .eq('business_id', currentBusiness.id)
        .eq('is_active', true)
        .order('name'),
      currentLocation?.id
        ? supabase
            .from('inventory_balances')
            .select('product_id, quantity_on_hand')
            .eq('business_id', currentBusiness.id)
            .eq('location_id', currentLocation.id)
        : Promise.resolve({ data: [] }),
    ]);

    const balanceMap = new Map((balanceRows || []).map((row) => [row.product_id, row.quantity_on_hand]));
    setProducts((productRows || []).map((row) => ({
      ...row,
      quantity_on_hand: balanceMap.get(row.id) ?? 0,
    })));
    setCategories(categoryRows || []);
    setSuppliers(supplierRows || []);
  }

  function openCreate() {
    setEditing(null);
    setValues(emptyForm);
    setMessage('');
    setOpen(true);
  }

  function openEdit(row) {
    setEditing(row);
    setValues({
      ...emptyForm,
      ...row,
      opening_stock: row.quantity_on_hand || 0,
    });
    setMessage('');
    setOpen(true);
  }

  async function save(event) {
    event.preventDefault();
    if (!currentBusiness?.id) return;

    const payload = {
      business_id: currentBusiness.id,
      category_id: values.category_id || null,
      supplier_id: values.supplier_id || null,
      name: values.name,
      sku: values.sku || null,
      barcode: values.barcode || null,
      description: values.description,
      unit: values.unit,
      type: values.type,
      price: Number(values.price || 0),
      cost: Number(values.cost || 0),
      tax_rate: Number(values.tax_rate || 0),
      low_stock_point: Number(values.low_stock_point || 0),
      track_inventory: Boolean(values.track_inventory),
      is_active: Boolean(values.is_active),
    };

    try {
      let productId = editing?.id;

      if (editing?.id) {
        const { error } = await supabase.from('products').update(payload).eq('id', editing.id);
        if (error) throw error;
      } else {
        const { data, error } = await supabase.from('products').insert(payload).select('*').single();
        if (error) throw error;
        productId = data.id;
      }

      if (currentLocation?.id) {
        const { error: balanceError } = await supabase.from('inventory_balances').upsert({
          business_id: currentBusiness.id,
          product_id: productId,
          location_id: currentLocation.id,
          quantity_on_hand: Number(values.opening_stock || 0),
          reorder_point: Number(values.low_stock_point || 0),
        }, { onConflict: 'product_id,location_id' });
        if (balanceError) throw balanceError;
      }

      setOpen(false);
      await load();
    } catch (error) {
      setMessage(error.message || 'Could not save product');
    }
  }

  async function remove(row) {
    if (!confirm(`Delete ${row.name}?`)) return;
    const { error } = await supabase.from('products').delete().eq('id', row.id);
    if (error) {
      setMessage(error.message || 'Could not delete');
      return;
    }
    await load();
  }

  const categoryOptions = useMemo(() => categories.map((item) => ({ value: item.id, label: item.name })), [categories]);
  const supplierOptions = useMemo(() => suppliers.map((item) => ({ value: item.id, label: item.name })), [suppliers]);

  const rows = products.filter((row) => {
    const haystack = `${row.name} ${row.sku || ''} ${row.barcode || ''}`.toLowerCase();
    return haystack.includes(search.toLowerCase());
  });

  return (
    <div className="page-wrap">
      <SectionCard
        title="Products"
        description="Products support barcodes, supplier links, categories, low-stock thresholds and location-aware inventory."
        actions={
          <>
            <TextField label="Search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name, SKU or barcode" />
            <button className="btn-primary" onClick={openCreate}>Add product</button>
          </>
        }
      >
        {message ? <div className="mb-4 rounded-2xl border p-3 text-sm">{message}</div> : null}
        <DataGrid
          columns={[
            { key: 'name', label: 'Product' },
            { key: 'sku', label: 'SKU' },
            { key: 'barcode', label: 'Barcode' },
            { key: 'price', label: 'Sell', render: (row) => currency(row.price, settings?.currency_symbol || 'R') },
            { key: 'cost', label: 'Cost', render: (row) => currency(row.cost, settings?.currency_symbol || 'R') },
            { key: 'quantity_on_hand', label: 'On hand' },
            { key: 'category', label: 'Category', render: (row) => row.category?.name || '—' },
            {
              key: 'actions',
              label: 'Actions',
              render: (row) => (
                <div className="flex flex-wrap gap-2">
                  <button className="btn-soft" onClick={() => openEdit(row)}>Edit</button>
                  <button className="btn-danger" onClick={() => remove(row)}>Delete</button>
                </div>
              ),
            },
          ]}
          rows={rows}
        />
      </SectionCard>

      <ModalSheet
        open={open}
        title={editing ? 'Edit product' : 'New product'}
        onClose={() => setOpen(false)}
        footer={
          <div className="flex flex-wrap gap-3">
            <button className="btn-primary" onClick={save}>Save product</button>
            <button className="btn-soft" onClick={() => setOpen(false)}>Cancel</button>
          </div>
        }
      >
        <form className="grid gap-4 sm:grid-cols-2" onSubmit={save}>
          <TextField label="Name" value={values.name} onChange={(e) => setValues((c) => ({ ...c, name: e.target.value }))} />
          <TextField label="SKU" value={values.sku} onChange={(e) => setValues((c) => ({ ...c, sku: e.target.value }))} />
          <TextField label="Barcode" value={values.barcode} onChange={(e) => setValues((c) => ({ ...c, barcode: e.target.value }))} />
          <SelectField label="Category" options={categoryOptions} value={values.category_id} onChange={(e) => setValues((c) => ({ ...c, category_id: e.target.value }))} />
          <SelectField label="Supplier" options={supplierOptions} value={values.supplier_id} onChange={(e) => setValues((c) => ({ ...c, supplier_id: e.target.value }))} />
          <TextField label="Unit" value={values.unit} onChange={(e) => setValues((c) => ({ ...c, unit: e.target.value }))} />
          <SelectField
            label="Type"
            value={values.type}
            onChange={(e) => setValues((c) => ({ ...c, type: e.target.value }))}
            options={[
              { value: 'stocked', label: 'Stocked item' },
              { value: 'service', label: 'Service' },
            ]}
          />
          <TextField label="Selling price" type="number" value={values.price} onChange={(e) => setValues((c) => ({ ...c, price: e.target.value }))} />
          <TextField label="Cost price" type="number" value={values.cost} onChange={(e) => setValues((c) => ({ ...c, cost: e.target.value }))} />
          <TextField label="Tax rate %" type="number" value={values.tax_rate} onChange={(e) => setValues((c) => ({ ...c, tax_rate: e.target.value }))} />
          <TextField label="Low stock point" type="number" value={values.low_stock_point} onChange={(e) => setValues((c) => ({ ...c, low_stock_point: e.target.value }))} />
          <TextField label={`Opening stock${currentLocation ? ` (${currentLocation.name})` : ''}`} type="number" value={values.opening_stock} onChange={(e) => setValues((c) => ({ ...c, opening_stock: e.target.value }))} />
          <div className="sm:col-span-2">
            <TextAreaField label="Description" value={values.description} onChange={(e) => setValues((c) => ({ ...c, description: e.target.value }))} />
          </div>
          <CheckboxField label="Track inventory" checked={Boolean(values.track_inventory)} onChange={(e) => setValues((c) => ({ ...c, track_inventory: e.target.checked }))} />
          <CheckboxField label="Active" checked={Boolean(values.is_active)} onChange={(e) => setValues((c) => ({ ...c, is_active: e.target.checked }))} />
        </form>
        {message ? <div className="mt-4 rounded-2xl border p-3 text-sm">{message}</div> : null}
      </ModalSheet>
    </div>
  );
}
