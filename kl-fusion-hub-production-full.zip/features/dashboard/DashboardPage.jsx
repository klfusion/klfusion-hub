'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { BarChart3, Boxes, FileText, ShoppingCart, Truck } from 'lucide-react';
import { useApp } from '@/components/BusinessProvider';
import SectionCard from '@/components/SectionCard';
import { currency, shortDate } from '@/lib/format';

function Stat({ label, value, tone = 'default' }) {
  const toneClass = tone === 'danger'
    ? 'from-rose-500 to-rose-600 text-white'
    : tone === 'success'
    ? 'from-emerald-500 to-emerald-600 text-white'
    : 'from-slate-900 to-slate-700 text-white dark:from-slate-100 dark:to-white dark:text-slate-900';

  return (
    <div className={`rounded-3xl bg-gradient-to-br p-5 ${toneClass}`}>
      <div className="text-xs uppercase tracking-[0.22em] opacity-80">{label}</div>
      <div className="mt-3 text-3xl font-bold">{value}</div>
    </div>
  );
}

export default function DashboardPage() {
  const { currentBusiness, currentLocation, settings } = useApp();
  const [summary, setSummary] = useState(null);

  useEffect(() => {
    async function load() {
      if (!currentBusiness?.id) return;
      const url = new URL('/api/reports/summary', window.location.origin);
      url.searchParams.set('businessId', currentBusiness.id);
      if (currentLocation?.id) url.searchParams.set('locationId', currentLocation.id);
      const response = await fetch(url.toString());
      const data = await response.json();
      setSummary(data.data || null);
    }

    load();
  }, [currentBusiness?.id, currentLocation?.id]);

  return (
    <div className="page-wrap">
      <SectionCard
        title={`Welcome back${currentBusiness?.name ? `, ${currentBusiness.name}` : ''}`}
        description="Operational snapshot across sales, invoices, inventory, purchasing and quotations."
      >
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Stat label="Today sales" value={currency(summary?.today_sales || 0, settings?.currency_symbol || 'R')} tone="success" />
          <Stat label="Month sales" value={currency(summary?.month_sales || 0, settings?.currency_symbol || 'R')} />
          <Stat label="Outstanding invoices" value={currency(summary?.open_invoice_balance || 0, settings?.currency_symbol || 'R')} tone="danger" />
          <Stat label="This month expenses" value={currency(summary?.month_expenses || 0, settings?.currency_symbol || 'R')} />
        </div>
      </SectionCard>

      <div className="grid gap-5 xl:grid-cols-[1.4fr_1fr]">
        <SectionCard title="Quick actions" description="The most-used flows have one-tap access.">
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            <Link href="/pos" className="rounded-3xl border p-4 hover:bg-slate-50 dark:hover:bg-slate-900">
              <ShoppingCart size={18} />
              <div className="mt-3 font-semibold">Start a sale</div>
              <div className="mt-1 text-sm text-slate-500">POS with tender modal, stock deduction and receipt.</div>
            </Link>
            <Link href="/documents/invoices" className="rounded-3xl border p-4 hover:bg-slate-50 dark:hover:bg-slate-900">
              <FileText size={18} />
              <div className="mt-3 font-semibold">Create invoice</div>
              <div className="mt-1 text-sm text-slate-500">PDF-ready invoices, branded numbering and customer portal.</div>
            </Link>
            <Link href="/purchase-orders" className="rounded-3xl border p-4 hover:bg-slate-50 dark:hover:bg-slate-900">
              <Truck size={18} />
              <div className="mt-3 font-semibold">Purchase stock</div>
              <div className="mt-1 text-sm text-slate-500">Raise purchase orders and receive inventory into location stock.</div>
            </Link>
            <Link href="/inventory" className="rounded-3xl border p-4 hover:bg-slate-50 dark:hover:bg-slate-900">
              <Boxes size={18} />
              <div className="mt-3 font-semibold">Inventory</div>
              <div className="mt-1 text-sm text-slate-500">Low stock, adjustments, movements and transfer visibility.</div>
            </Link>
            <Link href="/reports" className="rounded-3xl border p-4 hover:bg-slate-50 dark:hover:bg-slate-900">
              <BarChart3 size={18} />
              <div className="mt-3 font-semibold">Reports</div>
              <div className="mt-1 text-sm text-slate-500">Top products, gross profit estimate, balances and trends.</div>
            </Link>
          </div>
        </SectionCard>

        <div className="grid gap-5">
          <SectionCard title="Low stock" description="Products nearing reorder thresholds.">
            <div className="grid gap-3">
              {(summary?.low_stock || []).length ? (
                summary.low_stock.map((item) => (
                  <div key={`${item.product_id}-${item.location_id}`} className="rounded-2xl border p-3">
                    <div className="font-medium">{item.product_name}</div>
                    <div className="mt-1 text-sm text-slate-500">
                      {item.location_name} · On hand {item.quantity_on_hand} / Reorder {item.low_stock_point}
                    </div>
                  </div>
                ))
              ) : (
                <div className="rounded-2xl border border-dashed p-4 text-sm text-slate-500">No low stock products right now.</div>
              )}
            </div>
          </SectionCard>

          <SectionCard title="Recent documents" description="Newest invoices and quotations.">
            <div className="grid gap-3">
              {(summary?.recent_documents || []).length ? (
                summary.recent_documents.map((item) => (
                  <div key={item.id} className="rounded-2xl border p-3">
                    <div className="flex items-center justify-between gap-2">
                      <div className="font-medium">{item.number}</div>
                      <span className="badge-muted capitalize">{item.status}</span>
                    </div>
                    <div className="mt-1 text-sm text-slate-500">
                      {item.document_type.toUpperCase()} · {shortDate(item.issue_date)} · {currency(item.total, settings?.currency_symbol || 'R')}
                    </div>
                  </div>
                ))
              ) : (
                <div className="rounded-2xl border border-dashed p-4 text-sm text-slate-500">No documents yet.</div>
              )}
            </div>
          </SectionCard>
        </div>
      </div>
    </div>
  );
}
