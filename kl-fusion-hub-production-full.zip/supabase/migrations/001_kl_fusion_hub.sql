create extension if not exists pgcrypto;

do $$ begin
  create type public.app_role as enum ('owner','admin','manager','cashier','accountant','viewer');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.sale_status as enum ('completed','refunded','voided');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.purchase_order_status as enum ('draft','ordered','partially_received','received','cancelled');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.transfer_status as enum ('draft','in_transit','received','cancelled');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.document_status as enum ('draft','sent','viewed','accepted','declined','partial','paid','overdue','cancelled');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.movement_type as enum ('opening_balance','sale','refund','purchase_receive','adjustment','transfer_in','transfer_out');
exception when duplicate_object then null; end $$;

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  phone text,
  avatar_url text,
  role_global text not null default 'user',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text,
  owner_id uuid not null references public.profiles(id) on delete restrict,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.business_counters (
  business_id uuid not null references public.businesses(id) on delete cascade,
  counter_key text not null,
  current_value bigint not null default 0,
  primary key (business_id, counter_key)
);

create table if not exists public.memberships (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role public.app_role not null default 'owner',
  status text not null default 'active',
  permissions jsonb not null default '{}'::jsonb,
  pos_pin_hash text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, user_id)
);

create table if not exists public.business_settings (
  business_id uuid primary key references public.businesses(id) on delete cascade,
  business_name text,
  tagline text,
  currency_code text not null default 'ZAR',
  currency_symbol text not null default 'R',
  timezone text not null default 'Africa/Johannesburg',
  vat_enabled boolean not null default true,
  vat_rate numeric(6,2) not null default 15.00,
  logo_url text,
  address text,
  email text,
  mobile text,
  website text,
  tax_number text,
  invoice_prefix text not null default 'INV',
  quote_prefix text not null default 'QTE',
  receipt_prefix text not null default 'SALE',
  purchase_order_prefix text not null default 'PO',
  bank_name text,
  account_holder text,
  account_number text,
  bank_code text,
  terms_and_conditions text,
  delivery_details text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.locations (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null,
  code text not null,
  address text,
  is_default boolean not null default false,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, code)
);

create table if not exists public.cash_registers (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  location_id uuid references public.locations(id) on delete cascade,
  name text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null,
  description text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, name)
);

create table if not exists public.suppliers (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null,
  code text,
  email text,
  phone text,
  address text,
  contact_person text,
  notes text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null,
  code text,
  email text,
  phone text,
  address text,
  tax_number text,
  credit_limit numeric(12,2) not null default 0,
  notes text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  category_id uuid references public.categories(id) on delete set null,
  supplier_id uuid references public.suppliers(id) on delete set null,
  name text not null,
  sku text,
  barcode text,
  description text,
  unit text not null default 'each',
  type text not null default 'stocked',
  cost numeric(12,2) not null default 0,
  price numeric(12,2) not null default 0,
  tax_rate numeric(6,2) not null default 15,
  track_inventory boolean not null default true,
  low_stock_point numeric(12,2) not null default 0,
  image_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists products_business_sku_idx on public.products (business_id, sku) where sku is not null;
create unique index if not exists products_business_barcode_idx on public.products (business_id, barcode) where barcode is not null;

create table if not exists public.inventory_balances (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  location_id uuid not null references public.locations(id) on delete cascade,
  quantity_on_hand numeric(14,3) not null default 0,
  reorder_point numeric(14,3) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (product_id, location_id)
);

create table if not exists public.inventory_movements (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  location_id uuid not null references public.locations(id) on delete cascade,
  movement_type public.movement_type not null,
  quantity_delta numeric(14,3) not null,
  unit_cost numeric(12,2) not null default 0,
  reference_table text,
  reference_id uuid,
  note text,
  performed_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.sales (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  location_id uuid references public.locations(id) on delete set null,
  sale_number text,
  customer_id uuid references public.customers(id) on delete set null,
  register_id uuid references public.cash_registers(id) on delete set null,
  status public.sale_status not null default 'completed',
  payment_status text not null default 'paid',
  subtotal numeric(12,2) not null default 0,
  tax_total numeric(12,2) not null default 0,
  discount_total numeric(12,2) not null default 0,
  total numeric(12,2) not null default 0,
  received_amount numeric(12,2) not null default 0,
  change_amount numeric(12,2) not null default 0,
  payment_method text,
  notes text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  name_snapshot text not null,
  sku_snapshot text,
  unit_cost_snapshot numeric(12,2) not null default 0,
  price numeric(12,2) not null default 0,
  quantity numeric(14,3) not null default 1,
  tax_amount numeric(12,2) not null default 0,
  discount_amount numeric(12,2) not null default 0,
  line_total numeric(12,2) not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.refunds (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  sale_id uuid not null references public.sales(id) on delete cascade,
  refund_number text,
  reason text,
  refund_method text,
  subtotal numeric(12,2) not null default 0,
  tax_total numeric(12,2) not null default 0,
  total numeric(12,2) not null default 0,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.refund_items (
  id uuid primary key default gen_random_uuid(),
  refund_id uuid not null references public.refunds(id) on delete cascade,
  sale_item_id uuid references public.sale_items(id) on delete set null,
  product_id uuid references public.products(id) on delete set null,
  quantity numeric(14,3) not null default 1,
  unit_price numeric(12,2) not null default 0,
  line_total numeric(12,2) not null default 0
);

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  location_id uuid references public.locations(id) on delete set null,
  supplier_id uuid references public.suppliers(id) on delete set null,
  description text not null,
  category text,
  amount numeric(12,2) not null default 0,
  expense_date date not null default current_date,
  payment_method text,
  notes text,
  status text not null default 'posted',
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.purchase_orders (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  location_id uuid references public.locations(id) on delete set null,
  supplier_id uuid references public.suppliers(id) on delete set null,
  number text,
  status public.purchase_order_status not null default 'draft',
  ordered_at date not null default current_date,
  expected_at date,
  subtotal numeric(12,2) not null default 0,
  tax_total numeric(12,2) not null default 0,
  total numeric(12,2) not null default 0,
  notes text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.purchase_order_items (
  id uuid primary key default gen_random_uuid(),
  purchase_order_id uuid not null references public.purchase_orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  name_snapshot text not null,
  quantity numeric(14,3) not null default 1,
  unit_cost numeric(12,2) not null default 0,
  tax_amount numeric(12,2) not null default 0,
  line_total numeric(12,2) not null default 0,
  received_quantity numeric(14,3) not null default 0
);

create table if not exists public.transfer_orders (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  from_location_id uuid not null references public.locations(id) on delete cascade,
  to_location_id uuid not null references public.locations(id) on delete cascade,
  number text,
  status public.transfer_status not null default 'draft',
  notes text,
  created_by uuid references public.profiles(id) on delete set null,
  approved_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  dispatched_at timestamptz,
  received_at timestamptz,
  updated_at timestamptz not null default now()
);

create table if not exists public.transfer_order_items (
  id uuid primary key default gen_random_uuid(),
  transfer_order_id uuid not null references public.transfer_orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  name_snapshot text not null,
  quantity numeric(14,3) not null default 1
);

create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  location_id uuid references public.locations(id) on delete set null,
  document_type text not null check (document_type in ('invoice','quote')),
  number text,
  customer_id uuid references public.customers(id) on delete set null,
  status public.document_status not null default 'draft',
  issue_date date not null default current_date,
  due_date date,
  po_number text,
  currency_code text not null default 'ZAR',
  notes text,
  terms text,
  subtotal numeric(12,2) not null default 0,
  tax_total numeric(12,2) not null default 0,
  discount_total numeric(12,2) not null default 0,
  total numeric(12,2) not null default 0,
  balance_due numeric(12,2) not null default 0,
  portal_enabled boolean not null default false,
  portal_viewed_at timestamptz,
  accepted_at timestamptz,
  declined_at timestamptz,
  paid_at timestamptz,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.document_items (
  id uuid primary key default gen_random_uuid(),
  document_id uuid not null references public.documents(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  name_snapshot text not null,
  description text,
  quantity numeric(14,3) not null default 1,
  unit_price numeric(12,2) not null default 0,
  tax_rate numeric(6,2) not null default 0,
  tax_amount numeric(12,2) not null default 0,
  discount_amount numeric(12,2) not null default 0,
  line_total numeric(12,2) not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.recurring_document_templates (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  source_document_id uuid not null references public.documents(id) on delete cascade,
  document_type text not null check (document_type in ('invoice')),
  frequency text not null,
  interval_value integer not null default 1,
  next_run_at timestamptz not null,
  end_at timestamptz,
  is_active boolean not null default true,
  last_run_at timestamptz,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.portal_tokens (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  document_id uuid not null references public.documents(id) on delete cascade,
  token text not null unique,
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  last_viewed_at timestamptz
);

create table if not exists public.invitations (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  email text not null,
  role public.app_role not null default 'viewer',
  token text not null unique,
  status text not null default 'pending',
  expires_at timestamptz not null,
  invited_by uuid references public.profiles(id) on delete set null,
  accepted_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  entity_table text not null,
  entity_id uuid,
  action text not null,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

drop trigger if exists trg_profiles_updated_at on public.profiles;
create trigger trg_profiles_updated_at before update on public.profiles
for each row execute function public.set_updated_at();

drop trigger if exists trg_businesses_updated_at on public.businesses;
create trigger trg_businesses_updated_at before update on public.businesses
for each row execute function public.set_updated_at();

drop trigger if exists trg_memberships_updated_at on public.memberships;
create trigger trg_memberships_updated_at before update on public.memberships
for each row execute function public.set_updated_at();

drop trigger if exists trg_settings_updated_at on public.business_settings;
create trigger trg_settings_updated_at before update on public.business_settings
for each row execute function public.set_updated_at();

drop trigger if exists trg_locations_updated_at on public.locations;
create trigger trg_locations_updated_at before update on public.locations
for each row execute function public.set_updated_at();

drop trigger if exists trg_categories_updated_at on public.categories;
create trigger trg_categories_updated_at before update on public.categories
for each row execute function public.set_updated_at();

drop trigger if exists trg_suppliers_updated_at on public.suppliers;
create trigger trg_suppliers_updated_at before update on public.suppliers
for each row execute function public.set_updated_at();

drop trigger if exists trg_customers_updated_at on public.customers;
create trigger trg_customers_updated_at before update on public.customers
for each row execute function public.set_updated_at();

drop trigger if exists trg_products_updated_at on public.products;
create trigger trg_products_updated_at before update on public.products
for each row execute function public.set_updated_at();

drop trigger if exists trg_inventory_updated_at on public.inventory_balances;
create trigger trg_inventory_updated_at before update on public.inventory_balances
for each row execute function public.set_updated_at();

drop trigger if exists trg_expenses_updated_at on public.expenses;
create trigger trg_expenses_updated_at before update on public.expenses
for each row execute function public.set_updated_at();


create or replace function public.assign_purchase_order_number()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.number is null or length(trim(new.number)) = 0 then
    new.number := public.next_business_number(new.business_id, 'purchase_order', coalesce((select purchase_order_prefix from public.business_settings where business_id = new.business_id), 'PO'));
  end if;
  return new;
end $$;

drop trigger if exists trg_purchase_order_number on public.purchase_orders;
create trigger trg_purchase_order_number
before insert on public.purchase_orders
for each row execute function public.assign_purchase_order_number();

create or replace function public.assign_transfer_order_number()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.number is null or length(trim(new.number)) = 0 then
    new.number := public.next_business_number(new.business_id, 'transfer_order', 'TRF');
  end if;
  return new;
end $$;

drop trigger if exists trg_transfer_order_number on public.transfer_orders;
create trigger trg_transfer_order_number
before insert on public.transfer_orders
for each row execute function public.assign_transfer_order_number();


drop trigger if exists trg_purchase_orders_updated_at on public.purchase_orders;
create trigger trg_purchase_orders_updated_at before update on public.purchase_orders
for each row execute function public.set_updated_at();

drop trigger if exists trg_transfer_orders_updated_at on public.transfer_orders;
create trigger trg_transfer_orders_updated_at before update on public.transfer_orders
for each row execute function public.set_updated_at();

drop trigger if exists trg_documents_updated_at on public.documents;
create trigger trg_documents_updated_at before update on public.documents
for each row execute function public.set_updated_at();

drop trigger if exists trg_recurring_updated_at on public.recurring_document_templates;
create trigger trg_recurring_updated_at before update on public.recurring_document_templates
for each row execute function public.set_updated_at();

create or replace function public.handle_new_user_profile()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', new.email), new.email)
  on conflict (id) do update
  set email = excluded.email,
      full_name = coalesce(excluded.full_name, public.profiles.full_name);
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user_profile();

create or replace function public.handle_new_business_defaults()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_location_id uuid;
begin
  insert into public.memberships (business_id, user_id, role, status)
  values (new.id, new.owner_id, 'owner', 'active')
  on conflict (business_id, user_id) do nothing;

  insert into public.business_settings (business_id, business_name)
  values (new.id, new.name)
  on conflict (business_id) do nothing;

  insert into public.locations (business_id, name, code, is_default)
  values (new.id, 'Main Store', 'MAIN', true)
  returning id into v_location_id;

  insert into public.cash_registers (business_id, location_id, name)
  values (new.id, v_location_id, 'Front Register');

  return new;
end $$;

drop trigger if exists on_business_created on public.businesses;
create trigger on_business_created
after insert on public.businesses
for each row execute function public.handle_new_business_defaults();

create or replace function public.handle_new_location_inventory()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.inventory_balances (business_id, product_id, location_id, quantity_on_hand, reorder_point)
  select new.business_id, p.id, new.id, 0, p.low_stock_point
  from public.products p
  where p.business_id = new.business_id
  on conflict (product_id, location_id) do nothing;
  return new;
end $$;

drop trigger if exists on_location_created on public.locations;
create trigger on_location_created
after insert on public.locations
for each row execute function public.handle_new_location_inventory();

create or replace function public.handle_new_product_inventory()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.inventory_balances (business_id, product_id, location_id, quantity_on_hand, reorder_point)
  select new.business_id, new.id, l.id, 0, new.low_stock_point
  from public.locations l
  where l.business_id = new.business_id
  on conflict (product_id, location_id) do nothing;
  return new;
end $$;

drop trigger if exists on_product_created on public.products;
create trigger on_product_created
after insert on public.products
for each row execute function public.handle_new_product_inventory();

create or replace function public.is_platform_admin()
returns boolean
language sql
stable
as $$
  select exists (
    select 1
    from public.profiles
    where id = auth.uid()
      and role_global = 'platform_admin'
  );
$$;

create or replace function public.is_business_member(target_business_id uuid)
returns boolean
language sql
stable
as $$
  select public.is_platform_admin()
  or exists (
    select 1
    from public.memberships
    where business_id = target_business_id
      and user_id = auth.uid()
      and status = 'active'
  );
$$;

create or replace function public.has_business_role(target_business_id uuid, allowed_roles text[])
returns boolean
language sql
stable
as $$
  select public.is_platform_admin()
  or exists (
    select 1
    from public.memberships
    where business_id = target_business_id
      and user_id = auth.uid()
      and status = 'active'
      and role::text = any(allowed_roles)
  );
$$;

create or replace function public.next_business_number(target_business_id uuid, target_key text, prefix text)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  v_current bigint;
begin
  insert into public.business_counters (business_id, counter_key, current_value)
  values (target_business_id, target_key, 1)
  on conflict (business_id, counter_key)
  do update set current_value = public.business_counters.current_value + 1
  returning current_value into v_current;

  return concat(prefix, '-', lpad(v_current::text, 6, '0'));
end $$;

create or replace function public.write_audit_log(target_business_id uuid, target_table text, target_id uuid, action_name text, target_payload jsonb default '{}'::jsonb)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.audit_logs (business_id, actor_id, entity_table, entity_id, action, payload)
  values (target_business_id, auth.uid(), target_table, target_id, action_name, coalesce(target_payload, '{}'::jsonb));
end $$;

create or replace function public.process_sale(payload jsonb)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_business_id uuid := (payload ->> 'business_id')::uuid;
  v_location_id uuid := nullif(payload ->> 'location_id', '')::uuid;
  v_customer_id uuid := nullif(payload ->> 'customer_id', '')::uuid;
  v_payment_method text := coalesce(payload ->> 'payment_method', 'cash');
  v_received_amount numeric(12,2) := coalesce((payload ->> 'received_amount')::numeric, 0);
  v_notes text := coalesce(payload ->> 'notes', '');
  v_sale_number text;
  v_sale_id uuid;
  v_subtotal numeric(12,2) := 0;
  v_tax_total numeric(12,2) := 0;
  v_total numeric(12,2) := 0;
  v_item jsonb;
  v_product record;
  v_qty numeric(14,3);
  v_unit_price numeric(12,2);
  v_unit_cost numeric(12,2);
  v_tax_rate numeric(6,2);
  v_line_subtotal numeric(12,2);
  v_line_tax numeric(12,2);
  v_line_total numeric(12,2);
  v_balance numeric(14,3);
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  if not public.has_business_role(v_business_id, array['owner','admin','manager','cashier']) then
    raise exception 'You do not have permission to complete sales';
  end if;

  if jsonb_array_length(coalesce(payload -> 'items', '[]'::jsonb)) = 0 then
    raise exception 'At least one cart item is required';
  end if;

  for v_item in select * from jsonb_array_elements(payload -> 'items') loop
    select *
    into v_product
    from public.products
    where id = (v_item ->> 'product_id')::uuid
      and business_id = v_business_id;

    if not found then
      raise exception 'Product not found';
    end if;

    v_qty := greatest(coalesce((v_item ->> 'quantity')::numeric, 1), 0);
    v_unit_price := coalesce((v_item ->> 'unit_price')::numeric, v_product.price, 0);
    v_unit_cost := coalesce((v_item ->> 'unit_cost')::numeric, v_product.cost, 0);
    v_tax_rate := coalesce((v_item ->> 'tax_rate')::numeric, v_product.tax_rate, 0);
    v_line_subtotal := round(v_qty * v_unit_price, 2);
    v_line_tax := round(v_line_subtotal * v_tax_rate / 100, 2);
    v_line_total := round(v_line_subtotal + v_line_tax, 2);

    if coalesce(v_product.track_inventory, true) then
      if v_location_id is null then
        raise exception 'A location is required for stocked products';
      end if;
      select quantity_on_hand
      into v_balance
      from public.inventory_balances
      where business_id = v_business_id
        and product_id = v_product.id
        and location_id = v_location_id
      for update;

      if coalesce(v_balance, 0) < v_qty then
        raise exception 'Insufficient stock for %', v_product.name;
      end if;
    end if;

    v_subtotal := round(v_subtotal + v_line_subtotal, 2);
    v_tax_total := round(v_tax_total + v_line_tax, 2);
    v_total := round(v_total + v_line_total, 2);
  end loop;

  select public.next_business_number(v_business_id, 'sale', coalesce((select receipt_prefix from public.business_settings where business_id = v_business_id), 'SALE'))
  into v_sale_number;

  insert into public.sales (
    business_id, location_id, sale_number, customer_id,
    subtotal, tax_total, total, received_amount, change_amount,
    payment_method, notes, created_by
  )
  values (
    v_business_id, v_location_id, v_sale_number, v_customer_id,
    v_subtotal, v_tax_total, v_total, v_received_amount,
    greatest(v_received_amount - v_total, 0),
    v_payment_method, v_notes, auth.uid()
  )
  returning id into v_sale_id;

  for v_item in select * from jsonb_array_elements(payload -> 'items') loop
    select *
    into v_product
    from public.products
    where id = (v_item ->> 'product_id')::uuid
      and business_id = v_business_id;

    v_qty := greatest(coalesce((v_item ->> 'quantity')::numeric, 1), 0);
    v_unit_price := coalesce((v_item ->> 'unit_price')::numeric, v_product.price, 0);
    v_unit_cost := coalesce((v_item ->> 'unit_cost')::numeric, v_product.cost, 0);
    v_tax_rate := coalesce((v_item ->> 'tax_rate')::numeric, v_product.tax_rate, 0);
    v_line_subtotal := round(v_qty * v_unit_price, 2);
    v_line_tax := round(v_line_subtotal * v_tax_rate / 100, 2);
    v_line_total := round(v_line_subtotal + v_line_tax, 2);

    insert into public.sale_items (
      sale_id, product_id, name_snapshot, sku_snapshot, unit_cost_snapshot,
      price, quantity, tax_amount, line_total
    )
    values (
      v_sale_id, v_product.id, v_product.name, v_product.sku, v_unit_cost,
      v_unit_price, v_qty, v_line_tax, v_line_total
    );

    if coalesce(v_product.track_inventory, true) then
      insert into public.inventory_balances (business_id, product_id, location_id, quantity_on_hand, reorder_point)
      values (v_business_id, v_product.id, v_location_id, 0, v_product.low_stock_point)
      on conflict (product_id, location_id) do nothing;

      update public.inventory_balances
      set quantity_on_hand = quantity_on_hand - v_qty
      where business_id = v_business_id
        and product_id = v_product.id
        and location_id = v_location_id;

      insert into public.inventory_movements (
        business_id, product_id, location_id, movement_type,
        quantity_delta, unit_cost, reference_table, reference_id, note, performed_by
      )
      values (
        v_business_id, v_product.id, v_location_id, 'sale',
        v_qty * -1, v_unit_cost, 'sales', v_sale_id, 'POS sale', auth.uid()
      );
    end if;
  end loop;

  perform public.write_audit_log(v_business_id, 'sales', v_sale_id, 'sale.completed', payload);
  return v_sale_id;
end $$;

create or replace function public.adjust_inventory(payload jsonb)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_business_id uuid := (payload ->> 'business_id')::uuid;
  v_location_id uuid := (payload ->> 'location_id')::uuid;
  v_product_id uuid := (payload ->> 'product_id')::uuid;
  v_qty_delta numeric(14,3) := coalesce((payload ->> 'quantity_delta')::numeric, 0);
  v_note text := coalesce(payload ->> 'note', 'Manual adjustment');
  v_product record;
  v_movement_id uuid;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  if not public.has_business_role(v_business_id, array['owner','admin','manager']) then
    raise exception 'You do not have permission to adjust stock';
  end if;

  select * into v_product from public.products where id = v_product_id and business_id = v_business_id;
  if not found then
    raise exception 'Product not found';
  end if;

  insert into public.inventory_balances (business_id, product_id, location_id, quantity_on_hand, reorder_point)
  values (v_business_id, v_product_id, v_location_id, 0, v_product.low_stock_point)
  on conflict (product_id, location_id) do nothing;

  update public.inventory_balances
  set quantity_on_hand = quantity_on_hand + v_qty_delta,
      reorder_point = v_product.low_stock_point
  where business_id = v_business_id
    and product_id = v_product_id
    and location_id = v_location_id;

  insert into public.inventory_movements (
    business_id, product_id, location_id, movement_type, quantity_delta,
    unit_cost, reference_table, note, performed_by
  )
  values (
    v_business_id, v_product_id, v_location_id, 'adjustment', v_qty_delta,
    v_product.cost, 'inventory_adjustment', v_note, auth.uid()
  )
  returning id into v_movement_id;

  perform public.write_audit_log(v_business_id, 'inventory_movements', v_movement_id, 'inventory.adjusted', payload);
  return v_movement_id;
end $$;

create or replace function public.process_refund(payload jsonb)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_sale_id uuid := (payload ->> 'sale_id')::uuid;
  v_sale record;
  v_refund_id uuid;
  v_refund_number text;
  v_item jsonb;
  v_sale_item record;
  v_refund_total numeric(12,2) := 0;
  v_refund_subtotal numeric(12,2) := 0;
  v_qty numeric(14,3);
  v_line_total numeric(12,2);
begin
  select * into v_sale from public.sales where id = v_sale_id;
  if not found then
    raise exception 'Sale not found';
  end if;

  if not public.has_business_role(v_sale.business_id, array['owner','admin','manager','cashier']) then
    raise exception 'You do not have permission to refund this sale';
  end if;

  select public.next_business_number(v_sale.business_id, 'refund', 'RF')
  into v_refund_number;

  for v_item in select * from jsonb_array_elements(coalesce(payload -> 'items', '[]'::jsonb)) loop
    select si.*, p.track_inventory, p.cost
    into v_sale_item
    from public.sale_items si
    left join public.products p on p.id = si.product_id
    where si.id = (v_item ->> 'sale_item_id')::uuid
      and si.sale_id = v_sale_id;

    if not found then
      continue;
    end if;

    v_qty := least(coalesce((v_item ->> 'refund_quantity')::numeric, 0), v_sale_item.quantity);
    if v_qty <= 0 then
      continue;
    end if;

    v_line_total := round(v_qty * v_sale_item.price, 2);
    v_refund_subtotal := round(v_refund_subtotal + v_line_total, 2);
    v_refund_total := round(v_refund_total + v_line_total + coalesce(v_sale_item.tax_amount, 0), 2);
  end loop;

  insert into public.refunds (
    business_id, sale_id, refund_number, reason, refund_method,
    subtotal, tax_total, total, created_by
  )
  values (
    v_sale.business_id, v_sale.id, v_refund_number, payload ->> 'reason', payload ->> 'refund_method',
    v_refund_subtotal, 0, v_refund_total, auth.uid()
  )
  returning id into v_refund_id;

  for v_item in select * from jsonb_array_elements(coalesce(payload -> 'items', '[]'::jsonb)) loop
    select si.*, p.track_inventory, p.cost
    into v_sale_item
    from public.sale_items si
    left join public.products p on p.id = si.product_id
    where si.id = (v_item ->> 'sale_item_id')::uuid
      and si.sale_id = v_sale_id;

    if not found then
      continue;
    end if;

    v_qty := least(coalesce((v_item ->> 'refund_quantity')::numeric, 0), v_sale_item.quantity);
    if v_qty <= 0 then
      continue;
    end if;

    v_line_total := round(v_qty * v_sale_item.price, 2);

    insert into public.refund_items (refund_id, sale_item_id, product_id, quantity, unit_price, line_total)
    values (v_refund_id, v_sale_item.id, v_sale_item.product_id, v_qty, v_sale_item.price, v_line_total);

    if coalesce(v_sale_item.track_inventory, true) and v_sale.location_id is not null then
      insert into public.inventory_balances (business_id, product_id, location_id, quantity_on_hand, reorder_point)
      values (v_sale.business_id, v_sale_item.product_id, v_sale.location_id, 0, 0)
      on conflict (product_id, location_id) do nothing;

      update public.inventory_balances
      set quantity_on_hand = quantity_on_hand + v_qty
      where business_id = v_sale.business_id
        and product_id = v_sale_item.product_id
        and location_id = v_sale.location_id;

      insert into public.inventory_movements (
        business_id, product_id, location_id, movement_type, quantity_delta,
        unit_cost, reference_table, reference_id, note, performed_by
      )
      values (
        v_sale.business_id, v_sale_item.product_id, v_sale.location_id, 'refund', v_qty,
        coalesce(v_sale_item.cost, 0), 'refunds', v_refund_id, 'Customer refund', auth.uid()
      );
    end if;
  end loop;

  update public.sales
  set status = 'refunded'
  where id = v_sale.id;

  perform public.write_audit_log(v_sale.business_id, 'refunds', v_refund_id, 'sale.refunded', payload);
  return v_refund_id;
end $$;

create or replace function public.receive_purchase_order(payload jsonb)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_po_id uuid := (payload ->> 'purchase_order_id')::uuid;
  v_po record;
  v_item record;
  v_delta numeric(14,3);
  v_final_status public.purchase_order_status := 'received';
begin
  select * into v_po from public.purchase_orders where id = v_po_id;
  if not found then
    raise exception 'Purchase order not found';
  end if;

  if not public.has_business_role(v_po.business_id, array['owner','admin','manager','accountant']) then
    raise exception 'You do not have permission to receive this order';
  end if;

  for v_item in
    select poi.*, p.low_stock_point
    from public.purchase_order_items poi
    left join public.products p on p.id = poi.product_id
    where poi.purchase_order_id = v_po.id
  loop
    v_delta := greatest(v_item.quantity - v_item.received_quantity, 0);
    if v_delta > 0 then
      insert into public.inventory_balances (business_id, product_id, location_id, quantity_on_hand, reorder_point)
      values (v_po.business_id, v_item.product_id, v_po.location_id, 0, coalesce(v_item.low_stock_point, 0))
      on conflict (product_id, location_id) do nothing;

      update public.inventory_balances
      set quantity_on_hand = quantity_on_hand + v_delta
      where business_id = v_po.business_id
        and product_id = v_item.product_id
        and location_id = v_po.location_id;

      update public.purchase_order_items
      set received_quantity = quantity
      where id = v_item.id;

      insert into public.inventory_movements (
        business_id, product_id, location_id, movement_type, quantity_delta,
        unit_cost, reference_table, reference_id, note, performed_by
      )
      values (
        v_po.business_id, v_item.product_id, v_po.location_id, 'purchase_receive', v_delta,
        v_item.unit_cost, 'purchase_orders', v_po.id, 'PO received', auth.uid()
      );
    end if;
  end loop;

  update public.purchase_orders
  set status = v_final_status
  where id = v_po.id;

  perform public.write_audit_log(v_po.business_id, 'purchase_orders', v_po.id, 'purchase_order.received', payload);
  return v_po.id;
end $$;

create or replace function public.receive_transfer_order(payload jsonb)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_transfer_id uuid := (payload ->> 'transfer_order_id')::uuid;
  v_transfer record;
  v_item record;
  v_source_balance numeric(14,3);
begin
  select * into v_transfer from public.transfer_orders where id = v_transfer_id;
  if not found then
    raise exception 'Transfer order not found';
  end if;

  if not public.has_business_role(v_transfer.business_id, array['owner','admin','manager']) then
    raise exception 'You do not have permission to complete this transfer';
  end if;

  for v_item in
    select toi.*, p.low_stock_point, p.cost
    from public.transfer_order_items toi
    left join public.products p on p.id = toi.product_id
    where toi.transfer_order_id = v_transfer.id
  loop
    select quantity_on_hand
    into v_source_balance
    from public.inventory_balances
    where business_id = v_transfer.business_id
      and product_id = v_item.product_id
      and location_id = v_transfer.from_location_id
    for update;

    if coalesce(v_source_balance, 0) < v_item.quantity then
      raise exception 'Insufficient stock to transfer %', v_item.name_snapshot;
    end if;

    insert into public.inventory_balances (business_id, product_id, location_id, quantity_on_hand, reorder_point)
    values (v_transfer.business_id, v_item.product_id, v_transfer.from_location_id, 0, coalesce(v_item.low_stock_point, 0))
    on conflict (product_id, location_id) do nothing;

    insert into public.inventory_balances (business_id, product_id, location_id, quantity_on_hand, reorder_point)
    values (v_transfer.business_id, v_item.product_id, v_transfer.to_location_id, 0, coalesce(v_item.low_stock_point, 0))
    on conflict (product_id, location_id) do nothing;

    update public.inventory_balances
    set quantity_on_hand = quantity_on_hand - v_item.quantity
    where business_id = v_transfer.business_id
      and product_id = v_item.product_id
      and location_id = v_transfer.from_location_id;

    update public.inventory_balances
    set quantity_on_hand = quantity_on_hand + v_item.quantity
    where business_id = v_transfer.business_id
      and product_id = v_item.product_id
      and location_id = v_transfer.to_location_id;

    insert into public.inventory_movements (
      business_id, product_id, location_id, movement_type, quantity_delta,
      unit_cost, reference_table, reference_id, note, performed_by
    )
    values
      (v_transfer.business_id, v_item.product_id, v_transfer.from_location_id, 'transfer_out', v_item.quantity * -1, coalesce(v_item.cost, 0), 'transfer_orders', v_transfer.id, 'Transfer out', auth.uid()),
      (v_transfer.business_id, v_item.product_id, v_transfer.to_location_id, 'transfer_in', v_item.quantity, coalesce(v_item.cost, 0), 'transfer_orders', v_transfer.id, 'Transfer in', auth.uid());
  end loop;

  update public.transfer_orders
  set status = 'received',
      dispatched_at = coalesce(dispatched_at, now()),
      received_at = now()
  where id = v_transfer.id;

  perform public.write_audit_log(v_transfer.business_id, 'transfer_orders', v_transfer.id, 'transfer.completed', payload);
  return v_transfer.id;
end $$;

create or replace function public.save_document(payload jsonb)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_document_id uuid;
  v_business_id uuid := (payload ->> 'business_id')::uuid;
  v_location_id uuid := nullif(payload ->> 'location_id', '')::uuid;
  v_document_type text := payload ->> 'document_type';
  v_customer_id uuid := nullif(payload ->> 'customer_id', '')::uuid;
  v_issue_date date := coalesce((payload ->> 'issue_date')::date, current_date);
  v_due_date date := nullif(payload ->> 'due_date', '')::date;
  v_po_number text := payload ->> 'po_number';
  v_notes text := payload ->> 'notes';
  v_terms text := payload ->> 'terms';
  v_currency_code text := coalesce(payload ->> 'currency_code', 'ZAR');
  v_number text;
  v_prefix text;
  v_subtotal numeric(12,2) := 0;
  v_tax_total numeric(12,2) := 0;
  v_total numeric(12,2) := 0;
  v_item jsonb;
  v_line_subtotal numeric(12,2);
  v_line_tax numeric(12,2);
  v_line_total numeric(12,2);
  v_template_id uuid;
begin
  if not public.has_business_role(v_business_id, array['owner','admin','manager','cashier','accountant']) then
    raise exception 'You do not have permission to save documents';
  end if;

  for v_item in select * from jsonb_array_elements(coalesce(payload -> 'items', '[]'::jsonb)) loop
    v_line_subtotal := round(coalesce((v_item ->> 'quantity')::numeric, 0) * coalesce((v_item ->> 'unit_price')::numeric, 0), 2);
    v_line_tax := round(v_line_subtotal * coalesce((v_item ->> 'tax_rate')::numeric, 0) / 100, 2);
    v_line_total := round(v_line_subtotal + v_line_tax, 2);
    v_subtotal := round(v_subtotal + v_line_subtotal, 2);
    v_tax_total := round(v_tax_total + v_line_tax, 2);
    v_total := round(v_total + v_line_total, 2);
  end loop;

  v_prefix := case when v_document_type = 'invoice'
    then coalesce((select invoice_prefix from public.business_settings where business_id = v_business_id), 'INV')
    else coalesce((select quote_prefix from public.business_settings where business_id = v_business_id), 'QTE')
  end;

  select public.next_business_number(v_business_id, v_document_type, v_prefix) into v_number;

  insert into public.documents (
    business_id, location_id, document_type, number, customer_id, status,
    issue_date, due_date, po_number, currency_code, notes, terms,
    subtotal, tax_total, total, balance_due, portal_enabled, created_by
  )
  values (
    v_business_id, v_location_id, v_document_type, v_number, v_customer_id,
    case when v_document_type = 'invoice' then 'sent' else 'sent' end,
    v_issue_date, v_due_date, v_po_number, v_currency_code, v_notes, v_terms,
    v_subtotal, v_tax_total, v_total, v_total, true, auth.uid()
  )
  returning id into v_document_id;

  for v_item in select * from jsonb_array_elements(coalesce(payload -> 'items', '[]'::jsonb)) loop
    v_line_subtotal := round(coalesce((v_item ->> 'quantity')::numeric, 0) * coalesce((v_item ->> 'unit_price')::numeric, 0), 2);
    v_line_tax := round(v_line_subtotal * coalesce((v_item ->> 'tax_rate')::numeric, 0) / 100, 2);
    v_line_total := round(v_line_subtotal + v_line_tax, 2);

    insert into public.document_items (
      document_id, product_id, name_snapshot, description, quantity, unit_price,
      tax_rate, tax_amount, line_total
    )
    values (
      v_document_id,
      nullif(v_item ->> 'product_id', '')::uuid,
      coalesce(v_item ->> 'name_snapshot', ''),
      v_item ->> 'description',
      coalesce((v_item ->> 'quantity')::numeric, 0),
      coalesce((v_item ->> 'unit_price')::numeric, 0),
      coalesce((v_item ->> 'tax_rate')::numeric, 0),
      v_line_tax,
      v_line_total
    );
  end loop;

  if coalesce((payload -> 'recurring' ->> 'enabled')::boolean, false) then
    insert into public.recurring_document_templates (
      business_id, source_document_id, document_type, frequency, interval_value,
      next_run_at, created_by
    )
    values (
      v_business_id, v_document_id, 'invoice',
      coalesce(payload -> 'recurring' ->> 'frequency', 'monthly'),
      coalesce((payload -> 'recurring' ->> 'interval_value')::integer, 1),
      coalesce((payload -> 'recurring' ->> 'next_run_at')::timestamptz, now() + interval '1 month'),
      auth.uid()
    )
    returning id into v_template_id;
  end if;

  perform public.write_audit_log(v_business_id, 'documents', v_document_id, 'document.saved', payload);
  return v_document_id;
end $$;

create or replace function public.create_portal_token(target_document_id uuid)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  v_document record;
  v_token text;
begin
  select * into v_document from public.documents where id = target_document_id;
  if not found then
    raise exception 'Document not found';
  end if;

  if not public.has_business_role(v_document.business_id, array['owner','admin','manager','cashier','accountant']) then
    raise exception 'You do not have permission to share this document';
  end if;

  v_token := replace(gen_random_uuid()::text, '-', '');

  insert into public.portal_tokens (business_id, document_id, token, expires_at)
  values (v_document.business_id, v_document.id, v_token, now() + interval '30 days');

  update public.documents
  set portal_enabled = true
  where id = target_document_id;

  return v_token;
end $$;

create or replace function public.get_portal_document(portal_token text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_token public.portal_tokens%rowtype;
  v_document public.documents%rowtype;
  v_business public.businesses%rowtype;
  v_customer public.customers%rowtype;
  v_settings public.business_settings%rowtype;
begin
  select * into v_token
  from public.portal_tokens
  where token = portal_token
    and (expires_at is null or expires_at > now());

  if not found then
    raise exception 'This portal link has expired';
  end if;

  select * into v_document from public.documents where id = v_token.document_id;
  select * into v_business from public.businesses where id = v_document.business_id;
  select * into v_settings from public.business_settings where business_id = v_document.business_id;
  if v_document.customer_id is not null then
    select * into v_customer from public.customers where id = v_document.customer_id;
  end if;

  update public.portal_tokens set last_viewed_at = now() where id = v_token.id;
  update public.documents set portal_viewed_at = now(), status = case when status = 'sent' then 'viewed' else status end where id = v_document.id;

  return jsonb_build_object(
    'document', to_jsonb(v_document),
    'business', to_jsonb(v_business),
    'settings', to_jsonb(v_settings),
    'customer', to_jsonb(v_customer),
    'items', (select coalesce(jsonb_agg(to_jsonb(di) order by di.created_at), '[]'::jsonb) from public.document_items di where di.document_id = v_document.id)
  );
end $$;

create or replace function public.respond_to_quote(portal_token text, decision text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_token public.portal_tokens%rowtype;
  v_document public.documents%rowtype;
begin
  select * into v_token from public.portal_tokens where token = portal_token and (expires_at is null or expires_at > now());
  if not found then
    raise exception 'Quote link is invalid or expired';
  end if;

  select * into v_document from public.documents where id = v_token.document_id and document_type = 'quote';
  if not found then
    raise exception 'Quote not found';
  end if;

  update public.documents
  set status = case when lower(decision) = 'accepted' then 'accepted'::public.document_status else 'declined'::public.document_status end,
      accepted_at = case when lower(decision) = 'accepted' then now() else accepted_at end,
      declined_at = case when lower(decision) = 'declined' then now() else declined_at end
  where id = v_document.id;

  return v_document.id;
end $$;

create or replace function public.accept_invitation(invitation_token text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_invite public.invitations%rowtype;
  v_membership_id uuid;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  select * into v_invite
  from public.invitations
  where token = invitation_token
    and status = 'pending'
    and expires_at > now();

  if not found then
    raise exception 'Invitation is invalid or expired';
  end if;

  if lower(coalesce((select email from public.profiles where id = auth.uid()), '')) <> lower(v_invite.email)
     and not public.is_platform_admin() then
    raise exception 'Invitation email does not match the signed-in account';
  end if;

  insert into public.memberships (business_id, user_id, role, status)
  values (v_invite.business_id, auth.uid(), v_invite.role, 'active')
  on conflict (business_id, user_id)
  do update set role = excluded.role, status = 'active'
  returning id into v_membership_id;

  update public.invitations
  set status = 'accepted',
      accepted_at = now()
  where id = v_invite.id;

  perform public.write_audit_log(v_invite.business_id, 'invitations', v_invite.id, 'invitation.accepted', jsonb_build_object('email', v_invite.email, 'role', v_invite.role));
  return v_membership_id;
end $$;

create or replace function public.run_due_recurring_documents()
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_template record;
  v_source public.documents%rowtype;
  v_new_doc_id uuid;
  v_counter integer := 0;
  v_next_run timestamptz;
  v_prefix text;
  v_number text;
  v_item record;
begin
  for v_template in
    select *
    from public.recurring_document_templates
    where is_active = true
      and next_run_at <= now()
      and (end_at is null or end_at >= now())
  loop
    select * into v_source from public.documents where id = v_template.source_document_id;
    if not found then
      continue;
    end if;

    v_prefix := coalesce((select invoice_prefix from public.business_settings where business_id = v_template.business_id), 'INV');
    select public.next_business_number(v_template.business_id, 'invoice', v_prefix) into v_number;

    insert into public.documents (
      business_id, location_id, document_type, number, customer_id, status,
      issue_date, due_date, po_number, currency_code, notes, terms,
      subtotal, tax_total, discount_total, total, balance_due, portal_enabled, created_by
    )
    values (
      v_source.business_id, v_source.location_id, 'invoice', v_number, v_source.customer_id, 'sent',
      current_date, current_date + interval '30 days', v_source.po_number, v_source.currency_code, v_source.notes, v_source.terms,
      v_source.subtotal, v_source.tax_total, v_source.discount_total, v_source.total, v_source.total, true, v_template.created_by
    )
    returning id into v_new_doc_id;

    for v_item in select * from public.document_items where document_id = v_source.id loop
      insert into public.document_items (
        document_id, product_id, name_snapshot, description,
        quantity, unit_price, tax_rate, tax_amount, discount_amount, line_total
      )
      values (
        v_new_doc_id, v_item.product_id, v_item.name_snapshot, v_item.description,
        v_item.quantity, v_item.unit_price, v_item.tax_rate, v_item.tax_amount, v_item.discount_amount, v_item.line_total
      );
    end loop;

    v_next_run := case v_template.frequency
      when 'daily' then v_template.next_run_at + make_interval(days => v_template.interval_value)
      when 'weekly' then v_template.next_run_at + make_interval(weeks => v_template.interval_value)
      when 'quarterly' then v_template.next_run_at + make_interval(months => 3 * v_template.interval_value)
      when 'yearly' then v_template.next_run_at + make_interval(years => v_template.interval_value)
      else v_template.next_run_at + make_interval(months => v_template.interval_value)
    end;

    update public.recurring_document_templates
    set last_run_at = now(),
        next_run_at = v_next_run
    where id = v_template.id;

    v_counter := v_counter + 1;
  end loop;

  return v_counter;
end $$;

create or replace function public.report_summary(target_business_id uuid, target_location_id uuid default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_today_sales numeric(12,2);
  v_month_sales numeric(12,2);
  v_month_expenses numeric(12,2);
  v_open_invoice_balance numeric(12,2);
  v_low_stock jsonb;
  v_top_products jsonb;
  v_recent_documents jsonb;
begin
  if not public.is_business_member(target_business_id) then
    raise exception 'Not allowed';
  end if;

  select coalesce(sum(total), 0)
  into v_today_sales
  from public.sales
  where business_id = target_business_id
    and (target_location_id is null or location_id = target_location_id)
    and created_at >= date_trunc('day', now());

  select coalesce(sum(total), 0)
  into v_month_sales
  from public.sales
  where business_id = target_business_id
    and (target_location_id is null or location_id = target_location_id)
    and created_at >= date_trunc('month', now());

  select coalesce(sum(amount), 0)
  into v_month_expenses
  from public.expenses
  where business_id = target_business_id
    and (target_location_id is null or location_id = target_location_id)
    and expense_date >= date_trunc('month', now())::date;

  select coalesce(sum(balance_due), 0)
  into v_open_invoice_balance
  from public.documents
  where business_id = target_business_id
    and document_type = 'invoice'
    and status in ('sent','viewed','partial','overdue');

  select coalesce(jsonb_agg(row_to_json(x)), '[]'::jsonb)
  into v_low_stock
  from (
    select ib.product_id, ib.location_id, ib.quantity_on_hand, greatest(ib.reorder_point, p.low_stock_point) as low_stock_point,
           p.name as product_name, l.name as location_name
    from public.inventory_balances ib
    join public.products p on p.id = ib.product_id
    join public.locations l on l.id = ib.location_id
    where ib.business_id = target_business_id
      and (target_location_id is null or ib.location_id = target_location_id)
      and ib.quantity_on_hand <= greatest(ib.reorder_point, p.low_stock_point)
    order by ib.quantity_on_hand asc, p.name asc
    limit 10
  ) x;

  select coalesce(jsonb_agg(row_to_json(x)), '[]'::jsonb)
  into v_top_products
  from (
    select si.product_id,
           max(si.name_snapshot) as product_name,
           sum(si.quantity) as units_sold,
           round(sum(si.line_total), 2) as sales_total
    from public.sale_items si
    join public.sales s on s.id = si.sale_id
    where s.business_id = target_business_id
      and (target_location_id is null or s.location_id = target_location_id)
      and s.created_at >= date_trunc('month', now())
    group by si.product_id
    order by sum(si.quantity) desc
    limit 10
  ) x;

  select coalesce(jsonb_agg(row_to_json(x)), '[]'::jsonb)
  into v_recent_documents
  from (
    select id, document_type, number, status, issue_date, total
    from public.documents
    where business_id = target_business_id
    order by created_at desc
    limit 6
  ) x;

  return jsonb_build_object(
    'today_sales', coalesce(v_today_sales, 0),
    'month_sales', coalesce(v_month_sales, 0),
    'month_expenses', coalesce(v_month_expenses, 0),
    'open_invoice_balance', coalesce(v_open_invoice_balance, 0),
    'low_stock', v_low_stock,
    'top_products', v_top_products,
    'recent_documents', v_recent_documents
  );
end $$;

alter table public.profiles enable row level security;
alter table public.businesses enable row level security;
alter table public.memberships enable row level security;
alter table public.business_settings enable row level security;
alter table public.locations enable row level security;
alter table public.categories enable row level security;
alter table public.suppliers enable row level security;
alter table public.customers enable row level security;
alter table public.products enable row level security;
alter table public.inventory_balances enable row level security;
alter table public.inventory_movements enable row level security;
alter table public.sales enable row level security;
alter table public.sale_items enable row level security;
alter table public.refunds enable row level security;
alter table public.refund_items enable row level security;
alter table public.expenses enable row level security;
alter table public.purchase_orders enable row level security;
alter table public.purchase_order_items enable row level security;
alter table public.transfer_orders enable row level security;
alter table public.transfer_order_items enable row level security;
alter table public.documents enable row level security;
alter table public.document_items enable row level security;
alter table public.recurring_document_templates enable row level security;
alter table public.invitations enable row level security;
alter table public.audit_logs enable row level security;

drop policy if exists "profiles self read" on public.profiles;
create policy "profiles self read" on public.profiles
for select using (id = auth.uid() or public.is_platform_admin());

drop policy if exists "profiles self write" on public.profiles;
create policy "profiles self write" on public.profiles
for update using (id = auth.uid() or public.is_platform_admin())
with check (id = auth.uid() or public.is_platform_admin());

drop policy if exists "businesses readable" on public.businesses;
create policy "businesses readable" on public.businesses
for select using (public.is_business_member(id) or owner_id = auth.uid() or public.is_platform_admin());

drop policy if exists "businesses insert" on public.businesses;
create policy "businesses insert" on public.businesses
for insert to authenticated with check (owner_id = auth.uid() or public.is_platform_admin());

drop policy if exists "businesses update" on public.businesses;
create policy "businesses update" on public.businesses
for update using (public.has_business_role(id, array['owner','admin']) or public.is_platform_admin())
with check (public.has_business_role(id, array['owner','admin']) or public.is_platform_admin());

drop policy if exists "memberships read" on public.memberships;
create policy "memberships read" on public.memberships
for select using (user_id = auth.uid() or public.has_business_role(business_id, array['owner','admin']) or public.is_platform_admin());

drop policy if exists "memberships write" on public.memberships;
create policy "memberships write" on public.memberships
for all using (public.has_business_role(business_id, array['owner','admin']) or public.is_platform_admin())
with check (public.has_business_role(business_id, array['owner','admin']) or public.is_platform_admin());

drop policy if exists "settings read" on public.business_settings;
create policy "settings read" on public.business_settings
for select using (public.is_business_member(business_id));

drop policy if exists "settings write" on public.business_settings;
create policy "settings write" on public.business_settings
for all using (public.has_business_role(business_id, array['owner','admin']))
with check (public.has_business_role(business_id, array['owner','admin']));

drop policy if exists "locations all" on public.locations;
create policy "locations all" on public.locations
for all using (public.is_business_member(business_id))
with check (public.has_business_role(business_id, array['owner','admin','manager']));

drop policy if exists "categories all" on public.categories;
create policy "categories all" on public.categories
for all using (public.is_business_member(business_id))
with check (public.has_business_role(business_id, array['owner','admin','manager']));

drop policy if exists "suppliers all" on public.suppliers;
create policy "suppliers all" on public.suppliers
for all using (public.is_business_member(business_id))
with check (public.has_business_role(business_id, array['owner','admin','manager','accountant']));

drop policy if exists "customers all" on public.customers;
create policy "customers all" on public.customers
for all using (public.is_business_member(business_id))
with check (public.has_business_role(business_id, array['owner','admin','manager','cashier','accountant']));

drop policy if exists "products all" on public.products;
create policy "products all" on public.products
for all using (public.is_business_member(business_id))
with check (public.has_business_role(business_id, array['owner','admin','manager']));

drop policy if exists "inventory balances all" on public.inventory_balances;
create policy "inventory balances all" on public.inventory_balances
for all using (public.is_business_member(business_id))
with check (public.has_business_role(business_id, array['owner','admin','manager','cashier']));

drop policy if exists "inventory movements read" on public.inventory_movements;
create policy "inventory movements read" on public.inventory_movements
for select using (public.is_business_member(business_id));

drop policy if exists "sales all" on public.sales;
create policy "sales all" on public.sales
for all using (public.is_business_member(business_id))
with check (public.has_business_role(business_id, array['owner','admin','manager','cashier']));

drop policy if exists "sale items read" on public.sale_items;
create policy "sale items read" on public.sale_items
for select using (exists (
  select 1 from public.sales s
  where s.id = sale_id
    and public.is_business_member(s.business_id)
));

drop policy if exists "refunds all" on public.refunds;
create policy "refunds all" on public.refunds
for all using (public.is_business_member(business_id))
with check (public.has_business_role(business_id, array['owner','admin','manager','cashier']));

drop policy if exists "refund items read" on public.refund_items;
create policy "refund items read" on public.refund_items
for select using (exists (
  select 1 from public.refunds r
  where r.id = refund_id
    and public.is_business_member(r.business_id)
));

drop policy if exists "expenses all" on public.expenses;
create policy "expenses all" on public.expenses
for all using (public.is_business_member(business_id))
with check (public.has_business_role(business_id, array['owner','admin','manager','accountant']));

drop policy if exists "purchase orders all" on public.purchase_orders;
create policy "purchase orders all" on public.purchase_orders
for all using (public.is_business_member(business_id))
with check (public.has_business_role(business_id, array['owner','admin','manager','accountant']));

drop policy if exists "purchase items all" on public.purchase_order_items;
create policy "purchase items all" on public.purchase_order_items
for all using (exists (
  select 1 from public.purchase_orders po
  where po.id = purchase_order_id
    and public.is_business_member(po.business_id)
))
with check (exists (
  select 1 from public.purchase_orders po
  where po.id = purchase_order_id
    and public.has_business_role(po.business_id, array['owner','admin','manager','accountant'])
));

drop policy if exists "transfer orders all" on public.transfer_orders;
create policy "transfer orders all" on public.transfer_orders
for all using (public.is_business_member(business_id))
with check (public.has_business_role(business_id, array['owner','admin','manager']));

drop policy if exists "transfer items all" on public.transfer_order_items;
create policy "transfer items all" on public.transfer_order_items
for all using (exists (
  select 1 from public.transfer_orders t
  where t.id = transfer_order_id
    and public.is_business_member(t.business_id)
))
with check (exists (
  select 1 from public.transfer_orders t
  where t.id = transfer_order_id
    and public.has_business_role(t.business_id, array['owner','admin','manager'])
));

drop policy if exists "documents all" on public.documents;
create policy "documents all" on public.documents
for all using (public.is_business_member(business_id))
with check (public.has_business_role(business_id, array['owner','admin','manager','cashier','accountant']));

drop policy if exists "document items all" on public.document_items;
create policy "document items all" on public.document_items
for all using (exists (
  select 1 from public.documents d
  where d.id = document_id
    and public.is_business_member(d.business_id)
))
with check (exists (
  select 1 from public.documents d
  where d.id = document_id
    and public.has_business_role(d.business_id, array['owner','admin','manager','cashier','accountant'])
));

drop policy if exists "recurring templates all" on public.recurring_document_templates;
create policy "recurring templates all" on public.recurring_document_templates
for all using (public.is_business_member(business_id))
with check (public.has_business_role(business_id, array['owner','admin','manager','accountant']));

drop policy if exists "invitations all" on public.invitations;
create policy "invitations all" on public.invitations
for all using (public.is_business_member(business_id))
with check (public.has_business_role(business_id, array['owner','admin']));

drop policy if exists "audit logs read" on public.audit_logs;
create policy "audit logs read" on public.audit_logs
for select using (public.has_business_role(business_id, array['owner','admin','manager']));

grant execute on function public.process_sale(jsonb) to authenticated;
grant execute on function public.adjust_inventory(jsonb) to authenticated;
grant execute on function public.process_refund(jsonb) to authenticated;
grant execute on function public.receive_purchase_order(jsonb) to authenticated;
grant execute on function public.receive_transfer_order(jsonb) to authenticated;
grant execute on function public.save_document(jsonb) to authenticated;
grant execute on function public.create_portal_token(uuid) to authenticated;
grant execute on function public.report_summary(uuid, uuid) to authenticated;
grant execute on function public.accept_invitation(text) to authenticated;
grant execute on function public.respond_to_quote(text, text) to authenticated;
grant execute on function public.get_portal_document(text) to anon, authenticated;
grant execute on function public.run_due_recurring_documents() to service_role;
