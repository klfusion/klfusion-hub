'use client';

import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { createClient } from '@/lib/supabase/browser';

const AppContext = createContext(null);

export function BusinessProvider({ initialUser, initialProfile, initialBusinesses, children }) {
  const supabase = createClient();
  const [profile, setProfile] = useState(initialProfile || null);
  const [businesses, setBusinesses] = useState(initialBusinesses || []);
  const [currentBusinessId, setCurrentBusinessId] = useState('');
  const [currentBusiness, setCurrentBusiness] = useState(null);
  const [settings, setSettings] = useState(null);
  const [locations, setLocations] = useState([]);
  const [currentLocationId, setCurrentLocationId] = useState('');
  const [loadingMeta, setLoadingMeta] = useState(false);

  useEffect(() => {
    const stored = typeof window !== 'undefined' ? localStorage.getItem('klf_current_business') : '';
    const initial = stored || initialBusinesses?.[0]?.id || '';
    setCurrentBusinessId(initial);
  }, [initialBusinesses]);

  useEffect(() => {
    const picked = businesses.find((item) => item.id === currentBusinessId) || businesses[0] || null;
    setCurrentBusiness(picked || null);

    if (picked?.id && typeof window !== 'undefined') {
      localStorage.setItem('klf_current_business', picked.id);
    }
  }, [businesses, currentBusinessId]);

  useEffect(() => {
    async function loadMeta() {
      if (!currentBusiness?.id) {
        setSettings(null);
        setLocations([]);
        return;
      }

      setLoadingMeta(true);

      const [{ data: settingsRow }, { data: locationRows }] = await Promise.all([
        supabase
          .from('business_settings')
          .select('*')
          .eq('business_id', currentBusiness.id)
          .maybeSingle(),
        supabase
          .from('locations')
          .select('*')
          .eq('business_id', currentBusiness.id)
          .eq('is_active', true)
          .order('is_default', { ascending: false })
          .order('name'),
      ]);

      setSettings(settingsRow || null);
      setLocations(locationRows || []);

      const storageKey = `klf_location_${currentBusiness.id}`;
      const storedLocation = typeof window !== 'undefined' ? localStorage.getItem(storageKey) : '';
      const pickedLocation = (locationRows || []).find((item) => item.id === storedLocation)?.id
        || (locationRows || []).find((item) => item.is_default)?.id
        || locationRows?.[0]?.id
        || '';
      setCurrentLocationId(pickedLocation);
      setLoadingMeta(false);
    }

    loadMeta();
  }, [currentBusiness?.id, supabase]);

  useEffect(() => {
    if (currentBusiness?.id && currentLocationId && typeof window !== 'undefined') {
      localStorage.setItem(`klf_location_${currentBusiness.id}`, currentLocationId);
    }
  }, [currentBusiness?.id, currentLocationId]);

  async function refreshProfile() {
    if (!initialUser?.id) return;
    const { data } = await supabase.from('profiles').select('*').eq('id', initialUser.id).maybeSingle();
    setProfile(data || null);
  }

  async function refreshBusinesses() {
    if (!initialUser?.id) return;
    const { data } = await supabase
      .from('memberships')
      .select('id, role, business:businesses(id, name, slug, is_active)')
      .eq('user_id', initialUser.id)
      .eq('status', 'active');

    const rows = (data || [])
      .filter((row) => row.business)
      .map((row) => ({
        ...row.business,
        membership_role: row.role,
      }));

    setBusinesses(rows);
    if (!rows.find((row) => row.id === currentBusinessId)) {
      setCurrentBusinessId(rows[0]?.id || '');
    }
  }

  async function refreshBusinessMeta() {
    if (!currentBusiness?.id) return;
    const [{ data: settingsRow }, { data: locationRows }] = await Promise.all([
      supabase.from('business_settings').select('*').eq('business_id', currentBusiness.id).maybeSingle(),
      supabase.from('locations').select('*').eq('business_id', currentBusiness.id).eq('is_active', true).order('is_default', { ascending: false }).order('name'),
    ]);
    setSettings(settingsRow || null);
    setLocations(locationRows || []);
  }

  const currentLocation = useMemo(
    () => locations.find((item) => item.id === currentLocationId) || locations[0] || null,
    [locations, currentLocationId]
  );

  const role = currentBusiness?.membership_role || null;

  const value = {
    user: initialUser,
    profile,
    setProfile,
    businesses,
    currentBusiness,
    currentBusinessId,
    setCurrentBusinessId,
    settings,
    locations,
    currentLocation,
    currentLocationId,
    setCurrentLocationId,
    role,
    loadingMeta,
    refreshProfile,
    refreshBusinesses,
    refreshBusinessMeta,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const value = useContext(AppContext);
  if (!value) {
    throw new Error('useApp must be used inside BusinessProvider');
  }
  return value;
}
