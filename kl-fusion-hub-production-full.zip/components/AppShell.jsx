'use client';

import Link from 'next/link';
import { useMemo, useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import {
  Building2,
  ChevronDown,
  LogOut,
  Menu,
  MoonStar,
  Store,
  SunMedium,
} from 'lucide-react';
import { BusinessProvider, useApp } from '@/components/BusinessProvider';
import { NAV_ITEMS } from '@/lib/constants';
import { classNames } from '@/lib/format';

function ShellInner({ children }) {
  const pathname = usePathname();
  const router = useRouter();
  const {
    profile,
    businesses,
    currentBusiness,
    currentBusinessId,
    setCurrentBusinessId,
    locations,
    currentLocationId,
    setCurrentLocationId,
    role,
  } = useApp();

  const [open, setOpen] = useState(false);
  const [dark, setDark] = useState(typeof document !== 'undefined' ? document.documentElement.classList.contains('dark') : false);

  const visibleNav = useMemo(() => {
    return NAV_ITEMS.filter((item) => {
      if (item.platformOnly && profile?.role_global !== 'platform_admin') return false;
      return true;
    });
  }, [profile?.role_global]);

  async function signOut() {
    await fetch('/api/logout', { method: 'POST' });
    router.push('/login');
    router.refresh();
  }

  function toggleTheme() {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle('dark', next);
    localStorage.setItem('klf_theme', next ? 'dark' : 'light');
  }

  return (
    <div className="min-h-screen">
      <div className="app-grid mx-auto grid min-h-screen max-w-7xl">
        <aside className={classNames(
          'fixed inset-y-0 left-0 z-50 w-72 border-r bg-white/95 p-4 backdrop-blur transition dark:bg-slate-950/95 md:static md:block',
          open ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        )}>
          <div className="panel flex h-full flex-col gap-4 p-4">
            <div className="flex items-center gap-3">
              <div className="rounded-2xl bg-sky-500 p-3 text-white">
                <Store size={20} />
              </div>
              <div>
                <div className="font-semibold">KL Fusion Hub</div>
                <div className="text-xs text-slate-500 dark:text-slate-400">{profile?.full_name || profile?.email}</div>
              </div>
            </div>

            <div className="rounded-2xl bg-slate-50 p-3 dark:bg-slate-900">
              <label className="field-label">Business</label>
              <div className="relative">
                <select
                  className="field appearance-none pr-10"
                  value={currentBusinessId || ''}
                  onChange={(e) => setCurrentBusinessId(e.target.value)}
                >
                  {businesses.map((item) => (
                    <option key={item.id} value={item.id}>{item.name}</option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-3 top-3.5 text-slate-400" size={18} />
              </div>

              <label className="field-label mt-3">Location</label>
              <div className="relative">
                <select
                  className="field appearance-none pr-10"
                  value={currentLocationId || ''}
                  onChange={(e) => setCurrentLocationId(e.target.value)}
                >
                  {locations.map((item) => (
                    <option key={item.id} value={item.id}>{item.name}</option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-3 top-3.5 text-slate-400" size={18} />
              </div>

              <div className="mt-3 rounded-2xl border border-dashed p-3 text-xs text-slate-500 dark:text-slate-400">
                Role: <span className="font-semibold capitalize text-slate-700 dark:text-slate-200">{role || '—'}</span>
              </div>
            </div>

            <nav className="grid gap-1 overflow-y-auto">
              {visibleNav.map((item) => {
                const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setOpen(false)}
                    className={classNames(
                      'rounded-2xl px-4 py-3 text-sm font-medium transition',
                      active
                        ? 'bg-sky-500 text-white'
                        : 'text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-900'
                    )}
                  >
                    {item.label}
                  </Link>
                );
              })}
            </nav>

            <div className="mt-auto grid gap-2">
              <button className="btn-soft w-full" onClick={toggleTheme}>
                {dark ? <SunMedium size={16} /> : <MoonStar size={16} />}
                <span className="ml-2">{dark ? 'Light mode' : 'Dark mode'}</span>
              </button>
              <button className="btn-secondary w-full" onClick={() => router.push('/select-business')}>
                <Building2 size={16} />
                <span className="ml-2">Manage businesses</span>
              </button>
              <button className="btn-danger w-full" onClick={signOut}>
                <LogOut size={16} />
                <span className="ml-2">Sign out</span>
              </button>
            </div>
          </div>
        </aside>

        <div className="flex min-h-screen flex-col">
          <header className="sticky top-0 z-30 border-b bg-white/85 px-4 py-3 backdrop-blur dark:bg-slate-950/85 md:px-6">
            <div className="mx-auto flex max-w-7xl items-center gap-3">
              <button className="btn-soft md:hidden" onClick={() => setOpen((value) => !value)}>
                <Menu size={18} />
              </button>
              <div>
                <div className="text-xs uppercase tracking-[0.2em] text-slate-400">KL Fusion Hub</div>
                <div className="font-semibold">{currentBusiness?.name || 'Select business'}</div>
              </div>
            </div>
          </header>

          <main className="flex-1">{children}</main>
        </div>
      </div>
    </div>
  );
}

export default function AppShell({ initialUser, initialProfile, initialBusinesses, children }) {
  return (
    <BusinessProvider
      initialUser={initialUser}
      initialProfile={initialProfile}
      initialBusinesses={initialBusinesses}
    >
      <ShellInner>{children}</ShellInner>
    </BusinessProvider>
  );
}
