export function TextField({ label, ...props }) {
  return (
    <label className="block">
      <span className="field-label">{label}</span>
      <input className="field" {...props} />
    </label>
  );
}

export function TextAreaField({ label, ...props }) {
  return (
    <label className="block">
      <span className="field-label">{label}</span>
      <textarea className="field min-h-28" {...props} />
    </label>
  );
}

export function SelectField({ label, options = [], placeholder = 'Select...', ...props }) {
  return (
    <label className="block">
      <span className="field-label">{label}</span>
      <select className="field" {...props}>
        <option value="">{placeholder}</option>
        {options.map((option) => (
          <option key={option.value} value={option.value}>{option.label}</option>
        ))}
      </select>
    </label>
  );
}

export function CheckboxField({ label, checked, ...props }) {
  return (
    <label className="flex items-center gap-3 rounded-2xl border p-3">
      <input type="checkbox" checked={checked} {...props} />
      <span className="text-sm font-medium">{label}</span>
    </label>
  );
}
