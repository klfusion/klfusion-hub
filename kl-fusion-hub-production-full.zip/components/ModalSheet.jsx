export default function ModalSheet({ open, title, children, onClose, footer }) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[70] bg-slate-950/60 p-4">
      <div className="mx-auto flex h-full max-w-3xl items-end justify-center md:items-center">
        <div className="panel max-h-[92vh] w-full overflow-hidden">
          <div className="flex items-center justify-between border-b px-4 py-4 sm:px-6">
            <h3 className="text-lg font-semibold">{title}</h3>
            <button className="btn-soft" onClick={onClose}>Close</button>
          </div>
          <div className="max-h-[70vh] overflow-y-auto px-4 py-4 sm:px-6">{children}</div>
          {footer ? <div className="border-t px-4 py-4 sm:px-6">{footer}</div> : null}
        </div>
      </div>
    </div>
  );
}
