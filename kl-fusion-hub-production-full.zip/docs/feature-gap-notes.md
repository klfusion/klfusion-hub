# Research-driven gaps addressed in this rebuild

The original static prototype already covered the basics: dashboard, POS, inventory deduction, invoices/quotes, settings and multi-business access.

This production rebuild adds higher-value operational features that are common in modern POS/accounting systems:

- purchase orders and supplier receiving
- multi-location inventory and transfer orders
- barcode-ready products
- refunds that restock inventory
- staff roles and membership admin
- invitation flow
- quote/invoice portal sharing
- recurring invoice templates
- audit logging
- receipt PDF generation
- low-stock and top-product reporting

These additions were chosen after comparing the prototype against current POS/invoicing feature sets from vendors such as Square, Shopify POS, Zoho Books / Inventory, and Odoo.
